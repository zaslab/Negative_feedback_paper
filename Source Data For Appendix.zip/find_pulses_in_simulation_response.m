function [pulses] = find_pulses_in_simulation_response(Ca,t)
%this function gets the time and signal vector of the neuron
%and return the spikes details.

%average resolution of data per second - to reduce calculation time
avg_rev = 5;

%change from ms to s.
t = t/1000;

%smooting the signal
%Ca = movmean(Ca,10);

%total time in s
tot_time = t(end) - t(1); 

%factor to reduce vector size for better performence
reduceSizeFactor = int32(round(length(t) / tot_time / avg_rev));

t = t(1:reduceSizeFactor:end);
Ca = Ca(1:reduceSizeFactor:end);

risePercent = 0.1;
fallPercent = 0.9;

[max_pks, max_locs] = findpeaks(Ca);
[min_pks, min_locs] = findpeaks(-Ca); 
min_pks = -min_pks;
if (length(min_pks) == length(max_pks))
    min_pks = [1e-7 ; min_pks];
    min_locs = [1 ; min_locs];
else
    min_pks = [1e-7 ; min_pks ; Ca(end)];
    min_locs = [1 ; min_locs ; length(Ca)];
end

pulses = struct([]);
if ~isempty(max_pks)
    for i = 1:(length(min_pks)-1)
        pulses(i).base_L = min_pks(i);
        pulses(i).peak = max_pks(i);
        pulses(i).base_R = min_pks(i+1);
        pulses(i).amplitude_L = pulses(i).peak - pulses(i).base_L;
        pulses(i).amplitude_R = pulses(i).peak - pulses(i).base_R;
        riseThreshold = risePercent * pulses(i).amplitude_L + pulses(i).base_L;
        pulses(i).startTime = min(t((Ca > riseThreshold)&(t > t(min_locs(i)))));
        fallThreshold = pulses(i).peak - fallPercent * pulses(i).amplitude_R;
        pulses(i).endTime = min(t((Ca < fallThreshold) & (t > t(max_locs(i)))));
    end
    pulses = arrayfun(@(x) setfield(x,'duration',x.endTime - x.startTime),pulses);
end
end
