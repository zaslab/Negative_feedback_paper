%%
load('Appendix_Figure_S4_data');
%% panel a
e16Worms = T1_5Min(T1_5Min.strain=='eat16',:);
timeStart = -10;
timeEnd = 340;
timeRed = timeStart:0.6:timeEnd;
redVals = zeros(length(timeRed),1);
redVals(timeRed>0 & timeRed<300) = 1;
redVals(timeRed>360 & timeRed<370) = 1;
intsForImage = [];
for i=1:height(e16Worms)
    thisFlur = e16Worms.flurCorrected{i};
    thisFlur(thisFlur<-0.1)=0.1;
    intsForImage(i,:) = interp1(e16Worms.timeCorrected{i},thisFlur,timeRed);
end

figure('units','normalized','outerposition',[0 0 1 1])

subplot(15,2,2)
plot(timeRed,redVals,'red','LineWidth',2)
ylim([-0.2 1.2])
xlim([timeStart,timeEnd])
set(gca,'XTickLabel',{})
set(gca,'YTick',[0 1])
yticklabels({'0.1 \muM','1.1 mM'})
title({'Concentration';'[\muM]'})
set(gca,'FontSize',16)
maxInt = 3;
intsForImage(intsForImage>maxInt)=maxInt;
subplot(15,2,4:2:30)
imagesc(timeRed,1:height(e16Worms),intsForImage)
xlabel('Time [s]')
set(gca,'FontSize',14)
set(gca,'yTick',14);
set(gca,'yTickLabel','N=14');
title('\DeltaF/F_0')

colormap(jet)
h = colorbar('southoutside');
h.Label.String = "\DeltaF/F_0";
set(gca,'FontSize',16)
%% panel b
figure
subplot(2,2,1);
p1Time = timeRed(timeRed>-10 & timeRed<60);
p1Inds = find(timeRed(timeRed>-10 & timeRed<60));
shadedErrorBar(p1Time,nanmedian(intsForImage(:,p1Inds)),mad(intsForImage(:,p1Inds),1),'blue',1)
ylim([-0.1 1.8])
xlim([-10,60])
xlabel('Time [s]')
ylabel("\DeltaF/F_0")
set(gca,'FontSize',20)