load('Appendix_Figure_S5_data.mat');
%% panel a
fontS = 20;
for i=1:size(manyPulsesIntMat,1)
    manyPulsesIntMat(i,:) =  (manyPulsesIntMat(i,:)-min(manyPulsesIntMat(i,:)))/(max( manyPulsesIntMat(i,:))-min(manyPulsesIntMat(i,:)));
end

for i=1:size(longPulseIntMat,1)
    longPulseIntMat(i,:) =  (longPulseIntMat(i,:)-min( longPulseIntMat(i,:)))/(max( longPulseIntMat(i,:))-min( longPulseIntMat(i,:)));
end

bottom = min(min(manyPulsesIntMat));
top = max(max(manyPulsesIntMat));
figure('units','normalized','outerposition',[0 0 1 1])

subplot(11,1,5)
schemePulses = zeros(length(interppolatedTimeManySteps),1);
for i=0:19
    schemePulses(interppolatedTimeManySteps>-1+i*20 & interppolatedTimeManySteps<5 + i*20)= 1;
end
schemePulses(interppolatedTimeManySteps>425& interppolatedTimeManySteps<430) =1;
plot(interppolatedTimeManySteps,schemePulses,'k','LineWidth',2)
xlim([min(interppolatedTimeManySteps),max(interppolatedTimeManySteps)])
ylim([-0.2, 1.2])
set(gca,'XTickLabel',{})
set(gca,'YTick',[0 1])
yticklabels({'0.1 \muM','1.1 mM'})
set(gca,'FontSize',fontS)

subplot(11,1,6:8)
nLawa = length(Tshort.strain(Tshort.strain=='lawa'));
imagesc(interppolatedTimeManySteps,1:nLawa, manyPulsesIntMat(Tshort.strain=='lawa',:));
ylabel('wt')
set(gca,'YTick',nLawa)
set(gca,'YTickLabel',{['N=' num2str(nLawa)]})
set(gca,'FontSize',fontS)
set(gca,'XTickLabel',{})

caxis manual
caxis([bottom top]);

nTax6 = length(Tshort.strain(Tshort.strain=='tax6'));
subplot(11,1,9:11)
imagesc(interppolatedTimeManySteps,1:nTax6, manyPulsesIntMat(Tshort.strain=='tax6',:));
ylabel('tax-6(p675)')
set(gca,'FontSize',fontS)
caxis manual
caxis([bottom top]);

xlabel('Time [sec]')
set(gca,'YTick',nTax6)
set(gca,'YTickLabel',{['N=' num2str(nTax6)]})

nLongLawa = height(Tlong);

subplot(11,1,1)
schemePulses = zeros(length(interppolatedTimeManySteps),1);
schemePulses(interppolatedTimeManySteps>-1& interppolatedTimeManySteps<385) =1;
schemePulses(interppolatedTimeManySteps>425& interppolatedTimeManySteps<430) =1;
plot(interppolatedTimeManySteps,schemePulses,'k','LineWidth',2)
xlim([min(interppolatedTimeManySteps),max(interppolatedTimeManySteps)])
ylim([-0.2, 1.2])
set(gca,'XTickLabel',{})
set(gca,'YTick',[0 1])
yticklabels({'0.1 \muM','1.1 mM'})
set(gca,'FontSize',fontS)

subplot(11,1,2:4)
imagesc(interppolatedTimeManySteps,1:nLongLawa, longPulseIntMat);
ylabel('wt')
set(gca,'XTickLabel',{})
set(gca,'FontSize',fontS)
caxis manual
caxis([bottom top]);
set(gca,'YTick',nLongLawa)
set(gca,'YTickLabel',{['N=' num2str(nLongLawa)]})

colormap('jet')

figure
cbh = colorbar();
colorTitleHandle = get(cbh,'ylabel');

set(colorTitleHandle ,'String','Normlized Intensity');
set(gca,'FontSize',fontS)
colormap('jet')

caxis manual
caxis([bottom top]);
%% analyze responses
rng(2)
allP1Long = [];
allP2Long = [];
for i = 1:height(Tlong)
    thisPeaks =   cell2mat(Tlong.peakInds(i));
    thisF = Tlong.flurCorrected{i};
    thisP1 = thisF(thisPeaks(1));
    thisP2 = thisF(thisPeaks(2));
    allP1Long(i) = thisP1;
    allP2Long(i) = thisP2;
end
Tlong.allP1 = allP1Long';
Tlong.allP2 = allP2Long';

allP1Short = [];
allP2Short = [];
allP20Short = [];
allP21Short = [];
allPeaksVals = [];
for i = 1:height(Tshort)
    thisPeaks =   cell2mat(Tshort.peakInds(i));
    thisF = Tshort.flurCorrected{i};
    allPeaksVals(i,:) = thisF(thisPeaks);      
end
Tshort.allP1 = allPeaksVals(:,1);
Tshort.allP2 = allPeaksVals(:,2);
Tshort.allP20 = allPeaksVals(:,20);
Tshort.allP21 = allPeaksVals(:,21);
%% panels e,f,g
thisFsize = 26
figure('units','normalized','outerposition',[0 0 1 1])
subplot(1,3,1)
aFirstL = allPeaksVals(Tshort.strain=='lawa',1);
aFirstT = allPeaksVals(Tshort.strain=='tax6',1);
aSecondL =  allPeaksVals(Tshort.strain=='lawa',21);
aSecondT = allPeaksVals(Tshort.strain=='tax6',21);
h1 = plot([zeros(length(aFirstL),1),ones(length(aFirstL),1)]',[aFirstL aSecondL]','b.-','MarkerSize',25);
hold on
h2 = plot([ones(length(aFirstT),1)*3,ones(length(aFirstT),1)*4]',[aFirstT aSecondT]','r.-','MarkerSize',25);

h3 = plot([-0.25 0.25],[median(aFirstL),median(aFirstL)],'black','LineWidth',4);
plot([0.75 1.25],[median(aSecondL),median(aSecondL)],'black','LineWidth',4)


plot([2.75 3.25],[median(aFirstT),median(aFirstT)],'black','LineWidth',4)
plot([3.75 4.25],[median(aSecondT),median(aSecondT)],'black','LineWidth',4)
set(gca,'XTick',[0.1,1.1,3.1,4.1])
set(gca,'xticklabels',{'first\newlinestep','last\newlinestep','first\newlinestep','last\newlinestep'})

ylabel('\DeltaF/F_0')
set(gca,'FontSize',thisFsize)
legend([h1(1) h2(1) h3(1)],{'wt','tax-6(p675)'})
subplot(1,3,2)
scatter(aFirstL,aFirstL-aSecondL,45,'b','filled')
hold on
scatter(aFirstT,aFirstT-aSecondT,45,'r','filled')


Pt = polyfit(aFirstT,aFirstT-aSecondT,1);
x0 = min(aFirstT) ; x1 = max(aFirstT) ;
xi = [x0 x1];
yi = Pt(1)*xi+Pt(2);
plot([x0 x1], yi,'r--')
[ctax6 ptax6] = corrcoef(aFirstT,aFirstT-aSecondT)
Pl = polyfit(aFirstL,aFirstL-aSecondL,1);
[cWT pWT] = corrcoef(aFirstL,aFirstL-aSecondL)

x0 = min(aFirstL) ; x1 = max(aFirstL) ;
xi = [x0 x1];
yi = Pl(1)*xi+Pl(2);
plot([x0 x1], yi,'b--')
xlim([0 8])

ylabel('A_f_i_r_s_t - A_l_a_s_t [\DeltaF/F_0]')
xlabel('A_f_i_r_s_t [\DeltaF/F_0]')
set(gca,'fontSize',thisFsize)
legend('wt','tax-6(p675)')

subplot(1,3,3)
aSecondL_norm = aSecondL./aFirstL;
aSecondT_norm = aSecondT./aFirstT;
aSecond_LongStep_norm = Tlong.allP2./Tlong.allP1;


aSecond_LongStep_normX = zeros(length(aSecond_LongStep_norm),1)+rand(length(aSecond_LongStep_norm),1);
aSecondL_normX = zeros(length(aSecondL_norm),1)+rand(length(aSecondL_norm),1)+2;
aSecondT_normX = zeros(length(aSecondT_norm),1)+rand(length(aSecondT_norm),1)+4;
dotSize = 45;
scatter(aSecond_LongStep_normX,Tlong.allP2,dotSize,'magenta','filled')
hold on
scatter(aSecondL_normX,aSecondL,dotSize,'b','filled')

plot([0.25 0.75],[median(Tlong.allP2),median(Tlong.allP2)],'black','LineWidth',4)

plot([2.25 2.75],[median(aSecondL),median(aSecondL)],'black','LineWidth',4)

xlim([-0.5 3.5])
set(gca,'xTick',[])
legend('Long step', 'Many steps')
set(gca,'fontSize',thisFsize)
ylabel({'Last pulse amplitude', '[\DeltaF/F_0]'})


disp('tax-6(p675) adapt:')
signrank(aSecondT,aFirstT)
disp('Lawa:')
signrank(aSecondL,aFirstL)

disp('first step stronger tax6:')
ranksum(aFirstT,aFirstL)

disp('second step stronger tax6:')
ranksum(aSecondT,aSecondL)
%% panels b,c,d
figure
clf
fontSize = 20;
spacing = 8;


strainsInShort = categorical(extractfield(wormsDataShort,'strain'));
wormsDataShortTax6 = wormsDataShort(strainsInShort=='tax6');
wormsDataShortLawa = wormsDataShort(strainsInShort=='lawa');

subplot(4,1,1)
startTime = 55;
endTime = 150;
lawaPlotInd = 18;
dotSize = 12;
wormToPlot = wormsDataShortLawa(lawaPlotInd);
plotTimeRange = wormToPlot.timeCorrected>startTime & wormToPlot.timeCorrected<endTime; 
plot(wormToPlot.timeCorrected(plotTimeRange),wormToPlot.flurCorrected(plotTimeRange),'b.','MarkerSize',dotSize)
set(gca,'FontSize',fontSize)
ylabel('\DeltaF/F_0')
startTime = 55;
endTime = 150;
tax6PlotInd  = 2;
wormToPlotT = wormsDataShortTax6(tax6PlotInd);
hold on
plotTimeRangeT = wormToPlotT.timeCorrected>startTime & wormToPlotT.timeCorrected<endTime; 

plot(wormToPlotT.timeCorrected(plotTimeRangeT),wormToPlotT.flurCorrected(plotTimeRangeT),'r.','MarkerSize',dotSize)
xlim([startTime endTime])
set(gca,'XTickLabel',{})
subplot(4,1,2)
plot(wormToPlot.timeCorrected(plotTimeRange),wormToPlot.flurCorrected(plotTimeRange)/max(wormToPlot.flurCorrected(plotTimeRange)),'b.','MarkerSize',dotSize)
hold on
plot(wormToPlotT.timeCorrected(plotTimeRangeT),wormToPlotT.flurCorrected(plotTimeRangeT)/max(wormToPlotT.flurCorrected(plotTimeRangeT)),'r.','MarkerSize',dotSize)
xlim([startTime endTime])
xlabel('Time [sec]')
ylabel({'Normalized','activity'})
legend('wt','\ittax-6(p675)')
set(gca,'FontSize',fontSize)
singlePulseMarkerSize = 8;
medianMarkerSize = 7;
subplot(2,2,3); grid on;
allMedRaiseTimesLawa = [];
allMedRaiseTimesTax6 = [];
counter = 1;
startFrom = 3;
for i = 1:length(wormsDataShortLawa)
    raiseTime = wormsDataShortLawa(i).riseTime;
    raiseTime = raiseTime(startFrom:end-1);
    medRaiseTime = median(raiseTime);
    allMedRaiseTimesLawa(i) =  medRaiseTime;
    x = i * ones(length(raiseTime),1);
    hold on;
    
    plot(counter,medRaiseTime,'Marker','o','MarkerEdgeColor', 'blue','MarkerFaceColor', 'blue','MarkerSize', medianMarkerSize)
    plot(linspace(counter-spacing/3,counter+spacing/3,length(raiseTime)),raiseTime,'.blue','MarkerSize',singlePulseMarkerSize)
    plot([counter+spacing/2, counter+spacing/2],[0 10],'black--')
    counter = counter+spacing;
end
set(gca,'FontSize',fontSize)

for i = 1:length(wormsDataShortTax6)
    raiseTime = wormsDataShortTax6(i).riseTime;
    raiseTime = raiseTime(startFrom:end-1);
    medRaiseTime = median(raiseTime);
    allMedRaiseTimesTax6(i) =  medRaiseTime;
    x = i * ones(length(raiseTime),1);
    hold on;
    
    plot(counter,medRaiseTime,'Marker','o','MarkerEdgeColor', 'red','MarkerFaceColor', 'red','MarkerSize', medianMarkerSize)
    plot(linspace(counter-spacing/3,counter+spacing/3,length(raiseTime)),raiseTime,'.r','MarkerSize',singlePulseMarkerSize)
    plot([counter+spacing/2, counter+spacing/2],[0 10],'black--')
    counter = counter+spacing;
end
xlim([-1*spacing/2, counter])
ylim([0, 5])
ylabel('Rise time [sec]')
set(gca,'xTick',[64,186])
set(gca,'xticklabel',{'\color{blue}wt','\color{red}\ittax-6(p675)'})
grid off


subplot(2,2,4); grid on;
counter = 1;
allMedAmpLawa = [];
allMedAmpTax6 = [];

    % only for making a legend with black color. 
    plot(-10,1,'Marker','o','MarkerEdgeColor', 'black','MarkerFaceColor', 'black','MarkerSize', medianMarkerSize,'Color','none')
    hold on;
    plot(linspace(-10,-9,2),[1,1],'.black','MarkerSize',singlePulseMarkerSize)
    %

for i = 1:length(wormsDataShortLawa)
    
    amp = wormsDataShortLawa(i).flurCorrected(wormsDataShortLawa(i).peakInds);
    amp = amp(startFrom:end-1);
    medAmp = median(amp);
    
    
    allMedAmpLawa(i) =  medAmp;
    x = i * ones(length(amp),1);
    hold on;
    
    plot(counter,medAmp,'Marker','o','MarkerEdgeColor', 'blue','MarkerFaceColor', 'blue','MarkerSize', medianMarkerSize)
    plot(linspace(counter-spacing/3,counter+spacing/3,length(amp)),amp,'.blue','MarkerSize',singlePulseMarkerSize)
    plot([counter+spacing/2, counter+spacing/2],[0 10],'black--')
    counter = counter+spacing;
end

for i = 1:length(wormsDataShortTax6)
    amp = wormsDataShortTax6(i).flurCorrected(wormsDataShortTax6(i).peakInds);
    amp = amp(startFrom:end-1);
    medAmp = median(amp);
    allMedAmpTax6(i) =  medAmp;
    x = i * ones(length(amp),1);
    hold on;
    
    plot(counter,medAmp,'Marker','o','MarkerEdgeColor', 'red','MarkerFaceColor', 'red','MarkerSize', medianMarkerSize)
    plot(linspace(counter-spacing/3,counter+spacing/3,length(amp)),amp,'.r','MarkerSize',singlePulseMarkerSize)
    plot([counter+spacing/2, counter+spacing/2],[0 10],'black--')
    counter = counter+spacing;
end
xlim([-1*spacing/2, counter])
ylim([0,7])
ylabel({'Pulse amplitude', '[\DeltaF/F_0]'})
set(gca,'xTick',[64,186])
set(gca,'xticklabel',{'\color{blue}wt','\color{red}\ittax-6(p675)'})
set(gca,'FontSize',fontSize)
legend('worm median','single pulse')