function [activityTable,allRed] = createNeuralActivityTable(allDatas,time,useCorreted)
%CREATENEURALACTIVITYTABLE Summary of this function goes here
%   Detailed explanation goes here

activityTable = zeros(length(allDatas),length(time));
allRed = zeros(length(allDatas),length(time));
for i = 1:length(allDatas)
    thisD = allDatas(i);
    thisFlur = thisD.flur;
    thisTime =  thisD.timeInSeconds;
   
    if useCorreted==1
        
        thisFlurShift = thisD.flurCorrected;
        thisFlurShift = thisFlurShift-min(thisFlurShift);
    else
        thisFlurShift = thisFlur;
    end
    thisMid = thisD.midGradientTime;
    thisSTime = thisTime-thisMid;
    thisAlignedFlur = interp1(thisSTime,thisFlurShift,time);
    thisAlignedGrad = interp1(thisSTime,thisD.redValuesInTime,time);
    thisAlignedGrad = (thisAlignedGrad-nanmin(thisAlignedGrad))/(nanmax(thisAlignedGrad)-nanmin(thisAlignedGrad));
    activityTable(i,:) = thisAlignedFlur;
    allRed(i,:) = thisAlignedGrad;
    
end


