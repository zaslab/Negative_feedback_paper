function [testResult] = test_pulses_in_simulation_response(pulses,gradType, varargin)

  p = inputParser;
  default_maxDuration = 60;
  default_tanhMidTime = 420;
  
  addOptional(p,'maxDuration',default_maxDuration);
  addOptional(p,'tanhMidTime',default_tanhMidTime);
  parse(p,varargin{:});
    
  
testResult = false;

if ~isempty(pulses)
    max_amplitude = max([pulses.amplitude_L]);
    pulses = pulses([pulses.amplitude_L] > (max_amplitude/50));
    pulseNum = length(pulses);
    switch gradType
        case 'step'
            if pulseNum == 1
                if pulses(1).duration < p.Results.maxDuration
                    testResult = true; 
                end
            end
        case 'multiStep'
            if pulseNum >= 4, testResult = true; end
        case 'tanh'
            if (pulseNum >= 3) && (pulseNum < 100) &&...
                ((length(pulses([pulses.startTime] < p.Results.tanhMidTime))...
                - length(pulses([pulses.startTime] > p.Results.tanhMidTime)))...
                > floor(pulseNum/10))
                testResult = true; 
            end
        case 'shortVSlong'
            if ((pulseNum == 4) &&...
               (abs(pulses(1).amplitude_L - pulses(3).amplitude_L) < (pulses(1).amplitude_L/100)) &&...
               ((pulses(2).amplitude_L - pulses(4).amplitude_L) > (pulses(2).amplitude_L/20)))
                testResult = true; 
            end
    end
end
end