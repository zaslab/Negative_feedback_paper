% tax6_282 is tax-6(p675)
% tax6_486 is tax-6(ok2065)
% tax6_282_rescue is tax-6(p675)+AWA::TAX-6

load ('Appendix_Figure_S3_data.mat')
time  = [-8.5*60:7*60];
doShift = true;
[activityTable,gradTable1] = createNeuralActivityTable(tax6_282,time,doShift);
[activityTable,gradTable2] = createNeuralActivityTable(osm6,time,doShift);
[activityTable,gradTable3] = createNeuralActivityTable(eat16,time,doShift);
[activityTable,gradTable4] = createNeuralActivityTable(arr1,time,doShift);
[activityTable,gradTable5] = createNeuralActivityTable(wt,time,doShift);
[activityTable,gradTable6] = createNeuralActivityTable(grk2,time,doShift);
[activityTable,gradTable7] = createNeuralActivityTable(odr3,time,doShift);
[activityTable,gradTable8] = createNeuralActivityTable(tax6_486,time,doShift);
[activityTable,gradTable9] = createNeuralActivityTable(tax6_282_rescue,time,doShift);

meanG = nanmean([gradTable1;gradTable2;gradTable3;gradTable4;gradTable5;gradTable6;gradTable7;gradTable8;gradTable9]);

%% panels a-e
xlimits = [-510 400];
rows = 11;
cols = 5;
fontsize = 16;
resizePanel = [0 0 0.025 0.015];
strains(1).name = 'wt'; 
strains(2).name = 'tax-6(ok2065)';  
strains(3).name = 'tax-6(p675)'; 
strains(4).name = 'tax-6(p675) + AWA::TAX-6'; 
strains(5).name = 'eat-16'; 

for i = 1:cols
    a = subplot(rows,cols,i);
    plot(time, meanG*DAMToUM(10^-4)*0.7,'black','linewidth',2)
    xlim(xlimits);
    set(gca,'xTickLabel',{})
    if i ~= 1, set(gca,'yTickLabel',{}), end;
    a.Position = a.Position + resizePanel;
    if i == 1, ylabel('Conc. [\muM]'), end;
    set(gca,'fontSize',fontsize)
    if i ~= 1,title(strains(i).name,'FontAngle','italic'); end;
    if i == 1,title(strains(i).name); end;

end
for i = 1:length(wt)
    a = subplot(rows,cols,i*cols + 1);
    plot(wt(i).syncTime, wt(i).flurCorrected,'linewidth',1.2); hold on;
    numPulses = length(wt(i).PulseInd);
    upper_y_lim = ceil(2.*max(wt(i).flurCorrected))./2;
    plot(wt(i).syncTime(wt(i).PulseInd), ones(1,numPulses)*upper_y_lim,...
            'Marker','.','MarkerEdgeColor','k','LineStyle', 'none','MarkerSize',12);
    xlim(xlimits);
    ylim([-0.3 upper_y_lim]);
    set(gca,'xTickLabel',{});
    set(gca,'fontSize',fontsize)
    if (upper_y_lim == floor(upper_y_lim)) & (upper_y_lim >=2)...
        , upper_y_lim = floor(upper_y_lim) - 1;, end;  
    yticks([0 ,floor(upper_y_lim)]);
    a.Position = a.Position + resizePanel;
    if i == 4, ylabel('\DeltaF/F_0');,end
end
set(gca, 'XTickMode', 'auto', 'XTickLabelMode', 'auto')
xticks([-350 -175 0 175 350]);
xlabel('Time [sec]');

for i = 1:length(tax6_486)
    a = subplot(rows,cols,i*cols + 2);
    plot(tax6_486(i).syncTime, tax6_486(i).flurCorrected,'linewidth',1.2); hold on;
    numPulses = length(tax6_486(i).PulseInd);
    upper_y_lim = ceil(2.*max(tax6_486(i).flurCorrected))./2;
    plot(tax6_486(i).syncTime(tax6_486(i).PulseInd), ones(1,numPulses)*upper_y_lim,...
            'Marker','.','MarkerEdgeColor','k','LineStyle', 'none','MarkerSize',12);
    xlim(xlimits);
    ylim([-0.3 upper_y_lim]);
    set(gca,'xTickLabel',{})
    set(gca,'fontSize',fontsize)
    if (upper_y_lim == floor(upper_y_lim)) & (upper_y_lim >=2)...
        , upper_y_lim = floor(upper_y_lim) - 1;, end;  
    yticks([0 ,floor(upper_y_lim)]);
    a.Position = a.Position + resizePanel;
end
set(gca, 'XTickMode', 'auto', 'XTickLabelMode', 'auto')
xticks([-350 -175 0 175 350]);
xlabel('Time [sec]');

for i = 1:length(tax6_282)
    a = subplot(rows,cols,i*cols + 3);
    plot(tax6_282(i).syncTime, tax6_282(i).flurCorrected,'linewidth',1.2); hold on;
    numPulses = length(tax6_282(i).PulseInd);
    upper_y_lim = ceil(2.*max(tax6_282(i).flurCorrected))./2;
    plot(tax6_282(i).syncTime(tax6_282(i).PulseInd), ones(1,numPulses)*upper_y_lim,...
            'Marker','.','MarkerEdgeColor','k','LineStyle', 'none','MarkerSize',12);
    xlim(xlimits);
    ylim([-0.3 upper_y_lim]);
    set(gca,'xTickLabel',{})
    set(gca,'fontSize',fontsize)
    if (upper_y_lim == floor(upper_y_lim)) & (upper_y_lim >=2)...
        , upper_y_lim = floor(upper_y_lim) - 1;, end;  
    yticks([0 ,floor(upper_y_lim)]);
    a.Position = a.Position + resizePanel;
end
set(gca, 'XTickMode', 'auto', 'XTickLabelMode', 'auto')
xticks([-350 -175 0 175 350]);
xlabel('Time [sec]');


for i = 1:length(tax6_282_rescue)
    a = subplot(rows,cols,i*cols + 4);
    plot(tax6_282_rescue(i).syncTime, tax6_282_rescue(i).flurCorrected,'linewidth',1.2); hold on;
    numPulses = length(tax6_282_rescue(i).PulseInd);
    upper_y_lim = ceil(2.*max(tax6_282_rescue(i).flurCorrected))./2;
    xlim(xlimits);
    set(gca,'xTickLabel',{})
    set(gca,'fontSize',fontsize)
    %if (upper_y_lim == floor(upper_y_lim)) & (upper_y_lim >=2)...
    %    , upper_y_lim = floor(upper_y_lim) - 1; end
    if floor(upper_y_lim) == 0, upper_y_lim = 1; end 
    plot(tax6_282_rescue(i).syncTime(tax6_282_rescue(i).PulseInd), ones(1,numPulses)*upper_y_lim,...
            'Marker','.','MarkerEdgeColor','k','LineStyle', 'none','MarkerSize',12);
        ylim([-0.3 upper_y_lim]);
    yticks([0 ,floor(upper_y_lim)]);
    a.Position = a.Position + resizePanel;
end
set(gca, 'XTickMode', 'auto', 'XTickLabelMode', 'auto')
xticks([-350 -175 0 175 350]);
xlabel('Time [sec]');

for i = 1:length(eat16)
    a = subplot(rows,cols,i*cols + 5);
    plot(eat16(i).syncTime, eat16(i).flurCorrected,'linewidth',1.2); hold on;
    numPulses = length(eat16(i).PulseInd);
    upper_y_lim = ceil(2.*max(eat16(i).flurCorrected))./2;
    plot(eat16(i).syncTime(eat16(i).PulseInd), ones(1,numPulses)*upper_y_lim,...
            'Marker','.','MarkerEdgeColor','k','LineStyle', 'none','MarkerSize',12);
    xlim(xlimits);
    set(gca,'xTickLabel',{})
    set(gca,'fontSize',fontsize)
%     if (upper_y_lim == floor(upper_y_lim)) & (upper_y_lim >=2)...
%         , upper_y_lim = floor(upper_y_lim) - 1;, end;  
        ylim([-0.3 upper_y_lim]);

    yticks([0 ,floor(upper_y_lim)]);
    a.Position = a.Position + resizePanel;
end
set(gca, 'XTickMode', 'auto', 'XTickLabelMode', 'auto')
xticks([-350 -175 0 175 350]);
xlabel('Time [sec]');

% Create line
annotation('line',[0.213325860175695 0.213020833333333],...
    [0.937019969278034 0.262720664589823],'LineStyle','--');

% Create line
annotation('line',[0.376787457296243 0.376055392874573],...
    [0.93855142101057 0.415741897201047],'LineStyle','--');

% Create line
annotation('line',[0.538784925573451 0.5390625],...
    [0.940087519320862 0.338525441329179],'LineStyle','--');

% Create line
annotation('line',[0.702133662762325 0.702083333333333],...
    [0.93855142101057 0.110072689511942],'LineStyle','--');

% Create line
annotation('line',[0.865625 0.864583333333333],...
    [0.938733125649013 0.339563862928349],'LineStyle','--');

%% panels f-i
figure();
xlimits = [-510 400];
rows = 11;
cols = 5;
fontsize = 16;
resizePanel = [0 0 0.025 0.015];
strains(1).name = 'arr-1'; 
strains(2).name = 'grk-2'; 
strains(3).name = 'odr-3'; 
strains(4).name = 'osm-6';
for i = 1:cols-1
    a = subplot(rows,cols,i);
    plot(time, meanG*DAMToUM(10^-4)*0.7,'black','linewidth',2)
    xlim(xlimits);
    set(gca,'xTickLabel',{})
    if i ~= 1, set(gca,'yTickLabel',{}), end;
    a.Position = a.Position + resizePanel;
    if i == 1, ylabel('Conc. [\muM]'), end;
    set(gca,'fontSize',fontsize)
    if i ~= 1,title(strains(i).name,'FontAngle','italic'); end;
    if i == 1,title(strains(i).name); end;

end
for i = 1:length(arr1)
    a = subplot(rows,cols,i*cols + 1);
    plot(arr1(i).syncTime, arr1(i).flurCorrected,'linewidth',1.2); hold on;
    numPulses = length(arr1(i).PulseInd);
    upper_y_lim = ceil(2.*max(arr1(i).flurCorrected))./2;
    plot(arr1(i).syncTime(arr1(i).PulseInd), ones(1,numPulses)*upper_y_lim,...
            'Marker','.','MarkerEdgeColor','k','LineStyle', 'none','MarkerSize',12);
    xlim(xlimits);
    set(gca,'xTickLabel',{});
    set(gca,'fontSize',fontsize)
    if (upper_y_lim == floor(upper_y_lim)) & (upper_y_lim >=2)...
        , upper_y_lim = floor(upper_y_lim) - 1;, end;  
        ylim([-0.3 upper_y_lim]);
    yticks([0 ,floor(upper_y_lim)]);
    a.Position = a.Position + resizePanel;
    if i == 4, ylabel('\DeltaF/F_0');,end
end
set(gca, 'XTickMode', 'auto', 'XTickLabelMode', 'auto')
xticks([-350 -175 0 175 350]);
xlabel('Time [sec]');

for i = 1:length(grk2)
    a = subplot(rows,cols,i*cols + 2);
    plot(grk2(i).syncTime, grk2(i).flurCorrected,'linewidth',1.2); hold on;
    numPulses = length(grk2(i).PulseInd);
    upper_y_lim = ceil(2.*max(grk2(i).flurCorrected))./2;
    plot(grk2(i).syncTime(grk2(i).PulseInd), ones(1,numPulses)*upper_y_lim,...
            'Marker','.','MarkerEdgeColor','k','LineStyle', 'none','MarkerSize',12);
    xlim(xlimits);
    set(gca,'xTickLabel',{})
    set(gca,'fontSize',fontsize)
%     if (upper_y_lim == floor(upper_y_lim)) & (upper_y_lim >=2)...
%         , upper_y_lim = floor(upper_y_lim) - 1;, end;  
    if floor(upper_y_lim) == 0, upper_y_lim = 1; end 
        ylim([-0.3 upper_y_lim]);
    yticks([0 ,floor(upper_y_lim)]);
    a.Position = a.Position + resizePanel;
end
set(gca, 'XTickMode', 'auto', 'XTickLabelMode', 'auto')
xticks([-350 -175 0 175 350]);
xlabel('Time [sec]');

for i = 1:length(odr3)
    a = subplot(rows,cols,i*cols + 3);
    plot(odr3(i).syncTime, odr3(i).flurCorrected,'linewidth',1.2); hold on;
    numPulses = length(odr3(i).PulseInd);
    upper_y_lim = ceil(2.*max(odr3(i).flurCorrected))./2;
    plot(odr3(i).syncTime(odr3(i).PulseInd), ones(1,numPulses)*upper_y_lim,...
            'Marker','.','MarkerEdgeColor','k','LineStyle', 'none','MarkerSize',12);
    xlim(xlimits);
    set(gca,'xTickLabel',{})
    set(gca,'fontSize',fontsize)
    if (upper_y_lim == floor(upper_y_lim)) & (upper_y_lim >=2)...
        , upper_y_lim = floor(upper_y_lim) - 1;, end;  
        if floor(upper_y_lim) == 0, upper_y_lim = 1; end 
     ylim([-0.3 upper_y_lim]);
    yticks([0 ,floor(upper_y_lim)]);
    a.Position = a.Position + resizePanel;
end
set(gca, 'XTickMode', 'auto', 'XTickLabelMode', 'auto')
xticks([-350 -175 0 175 350]);
xlabel('Time [sec]');

for i = 1:length(osm6)
    a = subplot(rows,cols,i*cols + 4);
    plot(osm6(i).syncTime, osm6(i).flurCorrected,'linewidth',1.2); hold on;
    numPulses = length(osm6(i).PulseInd);
    upper_y_lim = ceil(2.*max(osm6(i).flurCorrected))./2;
    plot(osm6(i).syncTime(osm6(i).PulseInd), ones(1,numPulses)*upper_y_lim,...
            'Marker','.','MarkerEdgeColor','k','LineStyle', 'none','MarkerSize',12);
    xlim(xlimits);
    set(gca,'xTickLabel',{})
    set(gca,'fontSize',fontsize)
%     if (upper_y_lim == floor(upper_y_lim)) & (upper_y_lim >=2)...
%         , upper_y_lim = floor(upper_y_lim) - 1;, end;  
    if floor(upper_y_lim) == 0, upper_y_lim = 1; end 
    ylim([-0.3 upper_y_lim]);
    yticks([0 ,floor(upper_y_lim)]);
    a.Position = a.Position + resizePanel;
end
set(gca, 'XTickMode', 'auto', 'XTickLabelMode', 'auto')
xticks([-350 -175 0 175 350]);
xlabel('Time [sec]');

% Create line
annotation('line',[0.213325860175695 0.213020833333333],...
    [0.937019969278034 0.263759086188993],'LineStyle','--');

% Create line
annotation('line',[0.375745790629576 0.376041666666667],...
    [0.93958984260974 0.11318795430945],'LineStyle','--');

% Create line
annotation('line',[0.538784925573451 0.5390625],...
    [0.942164362519201 0.415368639667705],'LineStyle','--');

% Create line
annotation('line',[0.701091996095659 0.7015625],...
    [0.939589842609739 0.110072689511942],'LineStyle','--');
