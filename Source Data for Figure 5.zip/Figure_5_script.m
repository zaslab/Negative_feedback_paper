%% general
%organize data
fLen = length(tax6(1).flur);
tax6Flur = zeros(length(tax6),fLen);
tax6FlurNorm = zeros(length(tax6),fLen);
wtFlur = zeros(length(wt),fLen);
wtFlurNorm =  zeros(length(wt),fLen);
lFlur = 630;
for i=1:length(tax6)
    thisFlur = tax6(i).flur(1:lFlur);
    tax6Flur(i,:) = thisFlur;
    thisMin = min(thisFlur);
    thisMax = max(thisFlur);
    tax6FlurNorm(i,:) = (thisFlur)/(thisMax);
end

for i=1:length(wt)
    thisFlur = wt(i).flur(1:lFlur);
    wtFlur(i,:) = thisFlur;
    thisMin = min(thisFlur);
    thisMax = max(thisFlur);
    wtFlurNorm(i,:) = (thisFlur)/(thisMax);
end

%fit exponential decay
dt = 0.3;
pointsToFitAfterPeak = round(30/dt);


p1wt = wtFlur(:,1:210);
p1Ampswt = max(p1wt,[],2);
p1Tax6 = tax6Flur(:,1:210);
p1AmpsTax6 = max(p1Tax6,[],2);
fitP1wt = fitNormFlurs(p1wt,dt,pointsToFitAfterPeak);
fitP1Tax6 = fitNormFlurs(p1Tax6,dt,pointsToFitAfterPeak);


p2wt = wtFlur(:,211:420);

p2Ampswt = max(p2wt,[],2);
p2Tax6 = tax6Flur(:,211:420);
p2AmpsTax6 = max(p2Tax6,[],2);
fitP2wt = fitNormFlurs(p2wt,dt,pointsToFitAfterPeak);
fitP2Tax6 = fitNormFlurs(p2Tax6,dt,pointsToFitAfterPeak);


p3wt = wtFlur(:,421:630);

p3Ampswt = max(p3wt,[],2);
p3Tax6 = tax6Flur(:,421:630);

p3AmpsTax6 = max(p3Tax6,[],2);
fitP3wt = fitNormFlurs(p3wt,dt,pointsToFitAfterPeak);
fitP3Tax6 = fitNormFlurs(p3Tax6,dt,pointsToFitAfterPeak);


allTausWt = [fitP1wt.tau];
allTausTax6 = [fitP1Tax6.tau];
%% panel a
figure('units','normalized','outerposition',[0 0 1 1])
time = linspace(0,60,length(p1wt(1,:)));
cMax = max([p1wt(:); p2wt(:); p3wt(:); p1Tax6(:); p2Tax6(:) ; p3Tax6(:)])-1;
cMin = min([p1wt(:); p2wt(:); p3wt(:); p1Tax6(:); p2Tax6(:) ; p3Tax6(:)])-1;
fSize = 24;

subplot(2,3,1)
imagesc(time,1:10,p1wt-1)
caxis([cMin cMax])
ylabel('wt','fontweight','bold')
set(gca,'XTickLabel',{})
set(gca,'YTick', 10)
set(gca,'YTickLabel','N = 10');
set(gca,'fontSize',fSize)
title('first activation');

subplot(2,3,2)
imagesc(time,1:10,p2wt-1)
set(gca,'XTickLabel',{})
caxis([cMin cMax])
set(gca,'YTick',[])
title('second activation');
set(gca,'fontSize',fSize)

subplot(2,3,3)
imagesc(time,1:10,p3wt-1)
set(gca,'XTickLabel',{})
caxis([cMin cMax])
set(gca,'YTick',[])
title('third activation');
set(gca,'fontSize',fSize)

subplot(2,3,4)
imagesc(time,1:10,p1Tax6-1)
set(gca,'fontSize',fSize)
set(gca,'YTick', 10)
set(gca,'YTickLabel','N = 10');
caxis([cMin cMax])
ylabel('\it tax-6(p675)','fontweight','bold')
xlabel('Time [sec]')

subplot(2,3,5)
imagesc(time,1:10,p2Tax6-1)
set(gca,'fontSize',fSize)
set(gca,'YTick',[])
caxis([cMin cMax])
xlabel('Time [sec]')

subplot(2,3,6)
imagesc(time,1:10,p3Tax6-1)
set(gca,'fontSize',fSize)
set(gca,'YTick',[])
caxis([cMin cMax])
colormap('jet')
xlabel('Time [sec]')

figure
colorbar
colormap('jet')
caxis([cMin cMax])
set(gca,'fontSize',fSize)
title('\DeltaF/F_s_t_a_r_t')
%% panel d
figure('units','normalized','outerposition',[0 0 1 1])

AllCols = [230, 25, 75; 60, 180, 75; 255, 225, 25; 0, 130, 200; 245, 130, 48; 145, 30, 180; 70, 240, 240; 240, 50, 230; 210, 245, 60; 250, 190, 190; 0, 128, 128; 230, 190, 255; 170, 110, 40; 255, 250, 200; 128, 0, 0;...
    170, 255, 195; 128, 128, 0; 255, 215, 180; 0, 0, 128; 128, 128, 128;  0, 0, 0]/255;

allPswt = [(p1wt'./max(p1wt'))'; (p2wt'./max(p2wt'))'; (p3wt'./max(p3wt'))'];
allPsTax6 = [(p1Tax6'./max(p1Tax6'))'; (p2Tax6'./max(p2Tax6'))'; (p3Tax6'./max(p3Tax6'))'];


allPsWTshort = allPswt(:,time<30);
[coeff,score,latent] = pca(allPsWTshort);
varianceCaptured = latent./sum(latent);
dotsCols = repmat(AllCols(1:10,:),3,1);

subplot(1,2,1)

scatter(score(:,1),score(:,2),500,dotsCols,'X','LineWidth',4)
xlabel('PC1')
ylabel('PC2')
set(gca,'FontSize',fSize)
ylim([-0.6 0.7])
title('WT Chrimson')
%% panel c
smoothSteps = 3;
timeBeforePeak = 1;
timeAfterPeak = 20 ;
[thisMax,ind]= max(thisFlur);
timeInds =length(ind-round(timeBeforePeak/dt):round(ind+timeAfterPeak/dt));

wtForPlotDer = zeros(size(wtFlur,1),timeInds);
wtForPlotFun = zeros(size(wtFlur,1),timeInds);
for i=1:size(wtFlur,1)
    thisFlur = wtFlur(i,:);
    thisFlur = thisFlur(1:210);
    
    [thisMax,ind]= max(thisFlur);
    
    thisFlurDiff = smooth(diff(thisFlur),smoothSteps);
    if ind-round(timeBeforePeak/dt)>=1
        thisLineDer = thisFlurDiff(ind-round(timeBeforePeak/dt):round(ind+timeAfterPeak/dt));
        thisLineFun =  thisFlur(ind-round(timeBeforePeak/dt):round(ind+timeAfterPeak/dt));
    else
        thisLineDer = thisFlurDiff(1:round(ind+timeAfterPeak/dt));
        thisLineFun= thisFlur(1:round(ind+timeAfterPeak/dt));
        padd = timeInds - length(thisLineDer);
        thisLineDer = [nan(padd,1); thisLineDer];
        thisLineFun= [nan(padd,1); thisLineFun'];
    end
    wtForPlotDer(i,:) = thisLineDer;
    wtForPlotFun(i,:) =thisLineFun;
end  


Tax6ForPlotDer = zeros(size(tax6Flur,1),timeInds);
Tax6ForPlotFun = zeros(size(tax6Flur,1),timeInds);
for i=1:size(tax6Flur,1)
    thisFlur = tax6Flur(i,:);
    thisFlur = thisFlur(1:210);
   
    [thisMax,ind]= max(thisFlur);
    thisFlurDiff = smooth(diff(thisFlur),smoothSteps);
    
    if ind-round(timeBeforePeak/dt)>=1
        thisLineDer = thisFlurDiff(ind-round(timeBeforePeak/dt):round(ind+timeAfterPeak/dt));
        thisLineFun =  thisFlur(ind-round(timeBeforePeak/dt):round(ind+timeAfterPeak/dt));
    else
        thisLineDer = thisFlurDiff(1:round(ind+timeAfterPeak/dt));
        thisLineFun= thisFlur(1:round(ind+timeAfterPeak/dt));
        padd = timeInds - length(thisLineDer);
        thisLineDer = [nan(padd,1); thisLineDer];
        thisLineFun= [nan(padd,1); thisLineFun'];
    end
    
    Tax6ForPlotDer(i,:) = thisLineDer;
    Tax6ForPlotFun(i,:) = thisLineFun;
end  

figure('units','normalized','outerposition',[0 0 1 1])
subplot(1,3,1)
plotTime = linspace(-1*timeBeforePeak,timeAfterPeak,length(wtForPlotFun(1,:)));

shadedErrorBar(plotTime,nanmedian(wtForPlotFun-1),mad(wtForPlotFun-1,1),'blue',1)
hold on
shadedErrorBar(plotTime,nanmedian(Tax6ForPlotFun-1),mad(Tax6ForPlotFun-1,1),'red',1)
set(gca,'FontSize',fSize)

ylabel('\DeltaF/F_s_t_a_r_t')
xlabel('Time [sec]')
xlim([-1*timeBeforePeak, timeAfterPeak])
legendLineWidth = 2;
legend('wt','','','','\it tax-6(p675)','','','')
%% panel b
figure('units','normalized','outerposition',[0 0 1 1])
subplot(1,3,1)
wtCols = cool(10);
medLineThickness = 6;
ampFontSize = 25;
for i=1:10
    plot([0 1 2],[p1Ampswt(i) p2Ampswt(i) p3Ampswt(i)]-1,'-','marker','.','markerSize',30,'color','blue')
    hold on
end
plot([-0.25 0.25], [median(p1Ampswt) median(p1Ampswt)]-1,'-black','lineWidth',medLineThickness)
plot([0.75 1.25], [median(p2Ampswt) median(p2Ampswt)]-1,'-black','lineWidth',medLineThickness)
plot([1.75 2.25], [median(p3Ampswt) median(p3Ampswt)]-1,'-black','lineWidth',medLineThickness)

tax6Cols = summer(10);

for i=1:10
    plot([4 5 6],[p1AmpsTax6(i) p2AmpsTax6(i) p3AmpsTax6(i)]-1,'-','marker','.','markerSize',30,'color','red')
    hold on
end

plot([3.75 4.25], [median(p1AmpsTax6) median(p1AmpsTax6)]-1,'-black','lineWidth',medLineThickness)
plot([4.75 5.25], [median(p2AmpsTax6) median(p2AmpsTax6)]-1,'-black','lineWidth',medLineThickness)
plot([5.75 6.25], [median(p3AmpsTax6) median(p3AmpsTax6)]-1,'-black','lineWidth',medLineThickness)
set(gca,'FontSize',ampFontSize)
set(gca,'xTick',[0 1 2 4 5 6])
set(gca,'xTickLabel',{'1^s^t', '2^n^d','3^r^d','1^s^t', '2^n^d','3^r^d'})

ylabel('Maximal amplitute [\DeltaF/F_s]')
xlim([-1 7])
ylim([0 cMax+1.2])
xlabel('       wt            \it tax-6(p675)');
%% statistics
%comare amps of 1,3 activations in wt, tax-6 chrimson:
amp_A1_vs_A3_wtPval = signrank(p1Ampswt,p3Ampswt)
amp_A1_vs_A3_tax6Pval = signrank(p1AmpsTax6,p3AmpsTax6)

amp_A1_vs_A1_tax6WTPval = signrank(p1AmpsTax6,p1Ampswt)
amp_A3_vs_A3_tax6WTPval = signrank(p3Ampswt,p1AmpsTax6)

%compare taus:
tau_Chrim_WT_vs_Tax6Pval = ranksum(allTausWt(:,1),allTausTax6(:,1))
%% functions
function [fitParams] = fitNormFlurs(flurs,dt,pointsTofitAfterPeak)
    %flurs in shape (nSamplesXsampleLength)
    sampNum = size(flurs,1);

%     figure( 'Name', 'untitled fit 1' );
    fitParams = table();
    for i=1:sampNum
        xData = (0:dt:dt*(size(flurs,2)-1))';
        thisFlur = flurs(i,:);
        [~,thisMaxInd] = max(thisFlur);
        thisFlur = thisFlur/mean(thisFlur(end-10:end));

        yData = thisFlur(thisMaxInd:thisMaxInd+pointsTofitAfterPeak)';
        xData = xData(1:length(yData));

        ft = fittype( 'a*exp(-(x)/b) + c', 'independent', 'x', 'dependent', 'y' );
        opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
        opts.Display = 'Off';

        opts.Lower = [0.01,0.01,-1];
        opts.Upper = [15,200,1];

        [fitresult, gof] = fit( xData, yData, ft, opts );

%         disp(gof)
%         subplot(6,7,i);
%         plot( fitresult, xData, yData );
%         xlabel x; ylabel y; grid on
%         title(num2str(i));

        fitParams(i,:) = table(fitresult.a, fitresult.b, fitresult.c,'VariableNames',{'A0','tau','c'});    
    end
end