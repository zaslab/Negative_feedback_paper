%% change each parameter seperately 
    
    parameters1 = struct;
    
    parameters1(1).comment                               =   'default values';
    parameters1(1).DA_step                               =   DAMToUM(10^-4);
    parameters1(1).DA_tanh                               =   DAMToUM(10^-4)/2*0.7;
    parameters1(1).C_L                                   =   25;
    parameters1(1).L_0                                   =   1; 
    parameters1(1).C_I                                   =   20 * 0.5;   
    parameters1(1).critic_receptor_activation            =   0.95; 
    parameters1(1).S2Ca_coeff                            =   1e-07;  
    parameters1(1).calcium_decay_time_const              =   4e3; %const
    parameters1(1).calcium_dependent_inhibition_coeff    =   0.05 * 100;
    parameters1(1).calcium_independent_inhibition_coeff  =   0.05 * 4e-5;
    parameters1(1).inhibition_decay_time_const           =   3e5;
    
    parameters1(2:471) = parameters1(1);
    j=1;

    spaces                                  =   -1:0.05:1;
    
    C_L                                     =    parameters1(1).C_L.* (10.^spaces); 
    L_0                                     =    parameters1(1).L_0.* (10.^spaces);
    C_I                                     =    parameters1(1).C_I.* (10.^spaces); 
    critic_receptor_activation              =    0.8:0.01:0.99;   
    S2Ca_coeff                              =    parameters1(1).S2Ca_coeff.* (10.^spaces);
    calcium_decay_time_const                =    parameters1(1).calcium_decay_time_const.* (10.^spaces); 
    calcium_dependent_inhibition_coeff      =    parameters1(1).calcium_dependent_inhibition_coeff.* (10.^spaces); 
    calcium_independent_inhibition_coeff    =    parameters1(1).calcium_independent_inhibition_coeff.* (10.^spaces); 
    inhibition_decay_time_const             =    parameters1(1).inhibition_decay_time_const.* (10.^spaces); 
    DA_step                                 =    parameters1(1).DA_step.* (10.^[-3:0.1:3]);
    DA_tanh                                 =    parameters1(1).DA_tanh.* (10.^[-3:0.1:3]);
    
    for i = 1:length(C_L)
        j = j + 1;
        parameters1(j).C_L = C_L(i);
        parameters1(j).comment = 'C_L';
    end
    for i = 1:length(L_0)
        j = j + 1;
        parameters1(j).L_0 = L_0(i);
        parameters1(j).comment = 'L_0';
    end
    for i = 1:length(C_I)
        j = j + 1;
        parameters1(j).C_I = C_I(i);
        parameters1(j).comment = 'C_I';
    end
    for i = 1:length(critic_receptor_activation)
        j = j + 1;
        parameters1(j).critic_receptor_activation = critic_receptor_activation(i);
        parameters1(j).comment = 'critic_receptor_activation';
    end
    for i = 1:length(S2Ca_coeff)
        j = j + 1;
        parameters1(j).S2Ca_coeff = S2Ca_coeff(i);
        parameters1(j).comment = 'S2Ca_coeff';
    end
    for i = 1:length(calcium_decay_time_const)
        j = j + 1;
        parameters1(j).calcium_decay_time_const = calcium_decay_time_const(i);
        parameters1(j).comment = 'calcium_decay_time_const';
    end
    for i = 1:length(calcium_dependent_inhibition_coeff)
        j = j + 1;
        parameters1(j).calcium_dependent_inhibition_coeff = calcium_dependent_inhibition_coeff(i);
        parameters1(j).comment = 'calcium_dependent_inhibition_coeff';
    end
    for i = 1:length(calcium_independent_inhibition_coeff)
        j = j + 1;
        parameters1(j).calcium_independent_inhibition_coeff = calcium_independent_inhibition_coeff(i);
        parameters1(j).comment = 'calcium_independent_inhibition_coeff';
    end
    for i = 1:length(inhibition_decay_time_const)
        j = j + 1;
        parameters1(j).inhibition_decay_time_const = inhibition_decay_time_const(i);
        parameters1(j).comment = 'inhibition_decay_time_const';
    end
    for i = 1:length(DA_step)
        j = j + 1;
        parameters1(j).DA_step = DA_step(i);
        parameters1(j).comment = 'DA_step';
    end
    for i = 1:length(DA_tanh)
        j = j + 1;
        parameters1(j).DA_tanh = DA_tanh(i);
        parameters1(j).comment = 'DA_tanh';
    end
%% simulation - change each parameter seperately (can load data instead)
for i = 1:j 

    disp(int2str(i));
    % step   
    [t , Ca] = GPCR_negative_feedback_simulation('ez',true,'show_output',false,'time_track',false,...
               'gradType',2,'t_end',390000,'ts',30000,'tf',330000,'amplitude',parameters1(i).DA_step,...
               'calcium_decay_time_const',parameters1(i).calcium_decay_time_const,'C_I',parameters1(i).C_I,...
               'C_L',parameters1(i).C_L,...
               'L_0', parameters1(i).L_0,'calcium_dependent_inhibition_coeff', parameters1(i).calcium_dependent_inhibition_coeff,...
               'inhibition_decay_time_const',parameters1(i).inhibition_decay_time_const,'critic_receptor_activation', parameters1(i).critic_receptor_activation,...
               'calcium_independent_inhibition_coeff',parameters1(i).calcium_independent_inhibition_coeff,'S2Ca_coeff',parameters1(i).S2Ca_coeff);      
    
    parameters1(i).stepPulses = find_pulses_in_simulation_response(Ca,t);
    % tanh
    [t , Ca] = GPCR_negative_feedback_simulation('ez',true,'show_output',false,'time_track',false,...
               'gradType',3,'t_end',840000,'ts',0,'tf',840000,'amplitude',parameters1(i).DA_tanh,...
               'calcium_decay_time_const',parameters1(i).calcium_decay_time_const,'C_I',parameters1(i).C_I,...
               'C_L',parameters1(i).C_L,...
               'L_0', parameters1(i).L_0,'calcium_dependent_inhibition_coeff', parameters1(i).calcium_dependent_inhibition_coeff,...
               'inhibition_decay_time_const',parameters1(i).inhibition_decay_time_const,'critic_receptor_activation', parameters1(i).critic_receptor_activation,...
               'calcium_independent_inhibition_coeff',parameters1(i).calcium_independent_inhibition_coeff,'S2Ca_coeff',parameters1(i).S2Ca_coeff);           
           
    parameters1(i).tanhPulses = find_pulses_in_simulation_response(Ca,t);
end
%% testing the pulses for exact adaptation and adaptation to gradient's derivative
 parameters1 = arrayfun(@(x) setfield(x,'stepTest',test_pulses_in_simulation_response(x.stepPulses,'step')),parameters1);
 parameters1 = arrayfun(@(x) setfield(x,'tanhTest',test_pulses_in_simulation_response(x.tanhPulses,'tanh','tanhMidTime', 420)),parameters1);
 parameters1 = arrayfun(@(x) setfield(x,'totTest',x.tanhTest * x.stepTest),parameters1);
 
 parameters1Tbl = struct2table(parameters1);
 parameters1Tbl.comment = categorical(parameters1Tbl.comment);
%% panel a
maxVal = [];
minVal = [];
indexInTable = [4:6 8:12];

for i = indexInTable
    tmp =  parameters1Tbl.comment == parameters1Tbl.Properties.VariableNames(i) & parameters1Tbl.totTest == 1;
    currTbl = parameters1Tbl(tmp,:);
    currArr = table2array(currTbl(:,i));
    maxVal = [maxVal max(currArr)];
    minVal = [minVal min(currArr)];
end

startParam = table2array(parameters1Tbl(1,indexInTable));
maxValPercent = (maxVal./startParam);
minValPercent = (minVal./startParam);
startParamPercent = ones(1,length(startParam));
varNames = categorical(parameters1Tbl.Properties.VariableNames(indexInTable));
varNames = reordercats(varNames,parameters1Tbl.Properties.VariableNames(indexInTable));
tmp2 = strcat(string(varNames), " : ", string(startParam));
varNamesWithVal = categorical(tmp2);
varNamesWithVal = reordercats(varNamesWithVal,tmp2); 
constNames = {'k_1','L_0','k_2','k_4','\tau_{C}','k_5','k_6','\tau_I'};
realVarNames = categorical(constNames);
realVarNames = reordercats(realVarNames, constNames);
figure();
plot(realVarNames,startParamPercent,'MarkerFaceColor',[0 0 0],...
        'MarkerSize',20,'Marker','.','LineStyle','none','Color',[0 0 0]);
hold on
errorbar(realVarNames,startParamPercent,startParamPercent - minValPercent,...
        maxValPercent - startParamPercent,'LineWidth',1.5,'Color',[0 0 1],'LineStyle', 'none');  
grid on;
set(gca,'yscale','log');
ylim([0.07 15]);
set(gca,'FontSize',20); 
ylabel('scanned value / initial value');
set(gca, 'YTickLabel',{'0.1','1','10'});
%% panel b
figure();
stem(categorical({'R_t'}),0.95,'BaseValue',2,'MarkerFaceColor',[0 0 0],...
        'MarkerSize',20,'Marker','.','LineStyle','none','Color',[0 0 0]);
hold on
errorbar(categorical({'R_t'}),0.95,0.95 - 0.83, 0.99 - 0.95,'LineWidth',1.5,'Color',[0 0 1]);  
ylim([-0.1 1.1]);
ylabel('value');
set(gca,'FontSize',20); 
yline(0); yline(1); 
%% panel c
startVals = 0.001*[parameters1(1).DA_step, parameters1(1).DA_tanh];
minVals = 0.001*[1.44 3.04];
maxVals = 0.001*[1.15e6 3.83e5];

gradientNames = categorical({'step -','sigmoid -'});
gradientNames = reordercats(gradientNames , {'step -','sigmoid -'});

figure1 = figure();
stem(gradientNames ,startVals,'BaseValue',10^7,'MarkerFaceColor',[0 0 0],...
        'MarkerSize',20,'Marker','.','LineStyle','none','Color',[0 0 0]);
hold on
errorbar(gradientNames,startVals,startVals - minVals,maxVals - startVals,'LineWidth',1.5,'Color',[0 0 1],'LineStyle', 'none');  
grid on;
set(gca,'yscale','log');
set(gca,'FontSize',16); 
ylim([10^-3.5 10^3.5]);
ylabel({'Ligand conc.','[mM]'});

annotation(figure1,'textbox',...
    [0.1777 0.1033 0.2977 0.0621],...
    'String','exact adaptation',...
    'LineStyle','none',...
    'HorizontalAlignment','center',...
    'FontSize',16,...
    'FitBoxToText','off');

annotation(figure1,'textbox',...
    [0.5499 0.1009 0.2977 0.0621],...
    'String',['adaptation to',sprintf('\n'),' first derivative'],...
    'LineStyle','none',...
    'HorizontalAlignment','center',...
    'FontSize',16,...
    'FitBoxToText','off');
%% change all parameters simultaniously
    parameters2 = struct;
    
    parameters2(1).comment                               =   'default values';
    parameters2(1).DA_step                               =   DAMToUM(10^-4);
    parameters2(1).DA_tanh                               =   DAMToUM(10^-4)/2*0.7;
    parameters2(1).C_L                                   =   25;
    parameters2(1).L_0                                   =   1; 
    parameters2(1).C_I                                   =   20 * 0.5;   
    parameters2(1).critic_receptor_activation            =   0.95; 
    parameters2(1).S2Ca_coeff                            =   1e-07;  
    parameters2(1).calcium_decay_time_const              =   4e3; %const
    parameters2(1).calcium_dependent_inhibition_coeff    =   0.05 * 100;
    parameters2(1).calcium_independent_inhibition_coeff  =   0.05 * 4e-5;
    parameters2(1).inhibition_decay_time_const           =   3e5;
    
    parameters2(2:1000) = parameters2(1);
    j = 1;
    outputOption = false;

    for i = 1:length(parameters2)-1
        j = j + 1; 
        factor = sqrt(10); %scan between x/factor to x*factor
        logFac = log10(factor);
        parameters2(j).comment                               =   'random';
        parameters2(j).C_L                                   =   parameters2(1).C_L * 10^(rand*2*logFac - logFac);   
        parameters2(j).L_0                                   =   parameters2(1).L_0 * 10^(rand*2*logFac - logFac);
        parameters2(j).C_I                                   =   parameters2(1).C_I * 10^(rand*2*logFac - logFac);  
        parameters2(j).S2Ca_coeff                            =   parameters2(1).S2Ca_coeff * 10^(rand*2*logFac - logFac);
        parameters2(j).calcium_decay_time_const              =   parameters2(1).calcium_decay_time_const * 10^(rand*2*logFac - logFac);
        parameters2(j).calcium_dependent_inhibition_coeff    =   parameters2(1).calcium_dependent_inhibition_coeff * 10^(rand*2*logFac - logFac);
        parameters2(j).calcium_independent_inhibition_coeff  =   parameters2(1).calcium_independent_inhibition_coeff * 10^(rand*2*logFac - logFac);
        parameters2(j).inhibition_decay_time_const           =   parameters2(1).inhibition_decay_time_const * 10^(rand*2*logFac - logFac);
    end
%% simulation - all parameters simultaniously (can load data instead)
for i = 1:j 

    disp(int2str(i));
    % step   
    [t , Ca] = GPCR_negative_feedback_simulation('ez',true,'show_output',false,'time_track',false,...
               'gradType',2,'t_end',390000,'ts',30000,'tf',330000,'amplitude',DAMToUM(10^-4),...
               'calcium_decay_time_const',parameters2(i).calcium_decay_time_const,'C_I',parameters2(i).C_I,...
               'C_L',parameters2(i).C_L,...
               'L_0', parameters2(i).L_0,'calcium_dependent_inhibition_coeff', parameters2(i).calcium_dependent_inhibition_coeff,...
               'inhibition_decay_time_const',parameters2(i).inhibition_decay_time_const,'critic_receptor_activation', parameters2(i).critic_receptor_activation,...
               'calcium_independent_inhibition_coeff',parameters2(i).calcium_independent_inhibition_coeff,'S2Ca_coeff',parameters2(i).S2Ca_coeff);      
    
    parameters2(i).stepPulses = find_pulses_in_simulation_response(Ca,t);
    % tanh
    [t , Ca] = GPCR_negative_feedback_simulation('ez',true,'show_output',false,'time_track',false,...
               'gradType',3,'t_end',840000,'ts',0,'tf',840000,'amplitude',DAMToUM(10^-4)/2*0.7,...
               'calcium_decay_time_const',parameters2(i).calcium_decay_time_const,'C_I',parameters2(i).C_I,...
               'C_L',parameters2(i).C_L,...
               'L_0', parameters2(i).L_0,'calcium_dependent_inhibition_coeff', parameters2(i).calcium_dependent_inhibition_coeff,...
               'inhibition_decay_time_const',parameters2(i).inhibition_decay_time_const,'critic_receptor_activation', parameters2(i).critic_receptor_activation,...
               'calcium_independent_inhibition_coeff',parameters2(i).calcium_independent_inhibition_coeff,'S2Ca_coeff',parameters2(i).S2Ca_coeff);           
           
    parameters2(i).tanhPulses = find_pulses_in_simulation_response(Ca,t);
end  
%% testing the pulses for exact adaptation and adaptation to gradient's derivative
 parameters2 = arrayfun(@(x) setfield(x,'stepTest',test_pulses_in_simulation_response(x.stepPulses,'step')),parameters2);
 parameters2 = arrayfun(@(x) setfield(x,'tanhTest',test_pulses_in_simulation_response(x.tanhPulses,'tanh','tanhMidTime', 420)),parameters2);
 parameters2 = arrayfun(@(x) setfield(x,'totTest',x.tanhTest * x.stepTest),parameters2);
 
 parameters2Tbl = struct2table(parameters2);
 parameters2Tbl.comment = categorical(parameters2Tbl.comment);
%% analyzie percentage of random parameters point that past the tests
percent = sum(table2array(parameters2Tbl(2:height(parameters2Tbl),17))) / (height(parameters2Tbl)-1)
%% panel d,e,f
inds = [514 531 539 569 598];
samples = length(inds);
indexInTable = [4:6 8:12];
startParam = table2array(parameters2Tbl(1,indexInTable));
varNames = categorical(parameters2Tbl.Properties.VariableNames(indexInTable));
varNames = reordercats(varNames,parameters2Tbl.Properties.VariableNames(indexInTable));
tmp2 = strcat(string(varNames), " : ", string(startParam)); 
constNames = {'k_1','L_0','k_2','k_4','\tau_{C}','k_5','k_6','\tau_I'};
realVarNames = categorical(constNames);
realVarNames = reordercats(realVarNames, constNames);
for i = 1:size(parameters2Tbl,1)
    currParam = table2array(parameters2Tbl(i,indexInTable));
    ParamRatio = currParam./startParam;
    parameters2(i).ratio = ParamRatio;  
end

for k = 1:samples
    [t1 , Ca1, L1] = GPCR_negative_feedback_simulation('ez',true,'show_output',false,'time_track',false,...
               'gradType',2,'t_end',390000,'ts',30000,'tf',330000,'amplitude',parameters2(inds(k)).DA_step,...
               'calcium_decay_time_const',parameters2(inds(k)).calcium_decay_time_const,'C_I',parameters2(inds(k)).C_I,...
               'C_L',parameters2(inds(k)).C_L,...
               'L_0', parameters2(inds(k)).L_0,'calcium_dependent_inhibition_coeff', parameters2(inds(k)).calcium_dependent_inhibition_coeff,...
               'inhibition_decay_time_const',parameters2(inds(k)).inhibition_decay_time_const,'critic_receptor_activation', parameters2(inds(k)).critic_receptor_activation,...
               'calcium_independent_inhibition_coeff',parameters2(inds(k)).calcium_independent_inhibition_coeff,'S2Ca_coeff',parameters2(inds(k)).S2Ca_coeff);      
    t1_plot = t1-30000;
    
    [t2 , Ca2,L2] = GPCR_negative_feedback_simulation('ez',true,'show_output',false,'time_track',false,...
               'gradType',3,'t_end',840000,'ts',0,'tf',840000,'amplitude',parameters2(inds(k)).DA_tanh,...
               'calcium_decay_time_const',parameters2(inds(k)).calcium_decay_time_const,'C_I',parameters2(inds(k)).C_I,...
               'C_L',parameters2(inds(k)).C_L,...
               'L_0', parameters2(inds(k)).L_0,'calcium_dependent_inhibition_coeff', parameters2(inds(k)).calcium_dependent_inhibition_coeff,...
               'inhibition_decay_time_const',parameters2(inds(k)).inhibition_decay_time_const,'critic_receptor_activation', parameters2(inds(k)).critic_receptor_activation,...
               'calcium_independent_inhibition_coeff',parameters2(inds(k)).calcium_independent_inhibition_coeff,'S2Ca_coeff',parameters2(inds(k)).S2Ca_coeff);           
    t2_plot = t2 - 840000/2;
    t_start_plot = -450;
    t_end_plot = 350;
    
    if k == 1
        subplot(samples+1,3,2)
        plot(t1_plot/1000,L1*10^-3,'LineWidth', 1.5, 'Color', 'k'); 
        xlim([min(t1_plot/1000) max(t1_plot/1000)]);
        set(gca,'xticklabel',{[]})
        set(gca,'FontSize',16); 
        set(gca,'YTick',[0 1]);
        ylabel('Ligand [mM]');
        grid on;
        
        subplot(samples+1,3,3)
        plot(t2_plot/1000,L2*10^-3,'LineWidth', 1.5, 'Color', 'k');
        xlim([t_start_plot t_end_plot]);
        set(gca,'xticklabel',{[]})
        set(gca,'FontSize',16); 
        set(gca,'YTick',[0 0.8]);
        ylabel('Ligand [mM]');
        grid on;
    end
           
    subplot(samples+1,3,(k-1)*3+1+3)
    stem(realVarNames,parameters2(inds(k)).ratio,'MarkerFaceColor',[0 0 0],...
        'MarkerSize',5,'Color',[0 0 0],'BaseValue',1);
    grid on;
    set(gca,'yscale','log');
    ylim([0.2 8]);
    set(gca,'FontSize',16); 
    set(gca, 'YTick',[0.3 ,1, 3]); 
    if k ~= samples, set(gca,'xticklabel',{[]}), end
    if k == samples,ylabel('simulated value / initial value'); end

    subplot(samples+1,3,(k-1)*3+2+3)
    plot(t1_plot/1000,Ca1*10^6,'LineWidth', 1.5, 'Color', 'b'); 
    ylim([-0.1*max(Ca1*10^6),1.1*max(Ca1*10^6)]);
    xlim([min(t1_plot/1000) max(t1_plot/1000)]);
    set(gca,'FontSize',16);
    if k ~= samples, set(gca,'XTickLabel',[]); end 
    if k == samples 
        xlabel('Time [Sec]');
        ylabel('Calcium conc. [\muM]');
    end 
    ax = gca;
    ax.XGrid = 'on';
    ax.YGrid = 'of';
    set(gca,'YTick',[0 round(max(Ca1*10^6-5),-1)]);

    subplot(samples+1,3,(k-1)*3+3+3)
    plot(t2_plot/1000,Ca2*10^6,'LineWidth', 1.5, 'Color', 'b'); 
    ylim([-0.1*max(Ca2*10^6),1.1*max(Ca2*10^6)]);
    xlim([t_start_plot t_end_plot]);
    set(gca,'FontSize',16);
    if k ~= samples, set(gca,'XTickLabel',[]); end
    if k == samples 
        xlabel('Time [Sec]'); 
        ylabel('Calcium conc. [\muM]');
    end
    ax = gca;
    ax.XGrid = 'on';
    ax.YGrid = 'of';
    set(gca,'YTick',[0 round(max(Ca2*10^6 - 5),-1)]);
end