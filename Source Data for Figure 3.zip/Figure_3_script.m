%% general
load('Figure_3_data');

%tax6_282 is tax-6(p675)
%tax6_282_rescue is tax-6(p675)+AWA::TAX-6
%tax6_486 is tax-6(ok2065)

time  = [-7.5*60:6*60];
doShift = true;
[activityTable,gradTable1] = createNeuralActivityTable(tax6_282,time,doShift);
[activityTable,gradTable2] = createNeuralActivityTable(osm6,time,doShift);
[activityTable,gradTable3] = createNeuralActivityTable(eat16,time,doShift);
[activityTable,gradTable4] = createNeuralActivityTable(arr1,time,doShift);
[activityTable,gradTable5] = createNeuralActivityTable(wt,time,doShift);
[activityTable,gradTable6] = createNeuralActivityTable(grk2,time,doShift);
[activityTable,gradTable7] = createNeuralActivityTable(odr3,time,doShift);
[activityTable,gradTable8] = createNeuralActivityTable(tax6_486,time,doShift);
[activityTable,gradTable9] = createNeuralActivityTable(tax6_282_rescue,time,doShift);
meanG = nanmean([gradTable1;gradTable2;gradTable3;gradTable4;gradTable5;gradTable6;gradTable7;gradTable8;gradTable9]);
%% panel a and b
fSize = 18;
cmax = 6;
cmin = -0.3;
time  = [-7.5*60:6*60];
figure('units','normalized','outerposition',[0 0 1 1])
subplot(17,2,1)
doShift = true;

subplot(19,2,1)
plot(time,meanG*DAMToUM(10^-4)*0.8,'black','linewidth',2)
set(gca,'fontSize',fSize)
set(gca,'xTickLabel',{})
yticks([0, 900]);
ylim([0 900]);
xlim([min(time),max(time)])
ylabel({'Conc.', '[\muM]'})
title('\DeltaF/F_0');

[activityTable,~] = createNeuralActivityTable(wt,time,doShift);
subplot(19,2,2)
plot(time,meanG*DAMToUM(10^-4)*0.8,'black','linewidth',2)
set(gca,'xTickLabel',{})
set(gca,'fontSize',fSize)
yticks([0, 900]);
ylim([0 900]);
xlim([min(time),max(time)])
title('Normalized activity');


subplot(19,2,[3 5])
imagesc(time,1:length(wt),activityTable)
caxis([cmin cmax])
title('wt')
set(gca,'fontSize',fSize)
set(gca,'xTickLabel',{})
set(gca,'yTick',length(wt))
set(gca,'yTickLabel',{['N=' num2str(length(wt))]})

subplot(19,2,[7 9])
[activityTable,~] = createNeuralActivityTable(tax6_486,time,doShift);
imagesc(time,1:length(tax6_486),activityTable)
caxis([cmin cmax])
title('\it tax-6(ok2065)')
set(gca,'fontSize',fSize)
set(gca,'xTickLabel',{})
set(gca,'yTick',length(tax6_486))
set(gca,'yTickLabel',{['N=' num2str(length(tax6_486))]})

subplot(19,2,[11 13])
[activityTable,~] = createNeuralActivityTable(tax6_282,time,doShift);
imagesc(time,1:length(tax6_282),activityTable)
caxis([cmin cmax])
title('\it tax-6(p675)')
set(gca,'fontSize',fSize)
set(gca,'xTickLabel',{})
set(gca,'yTick',length(tax6_282))
set(gca,'yTickLabel',{['N=' num2str(length(tax6_282))]})

subplot(19,2,[15 17])
[activityTable,~] = createNeuralActivityTable(tax6_282_rescue,time,doShift);
imagesc(time,1:length(tax6_282_rescue),activityTable)
caxis([cmin cmax])
title({'\it tax-6(p675)', '+ AWA::TAX-6'})
set(gca,'fontSize',fSize)
set(gca,'xTickLabel',{})
set(gca,'yTick',length(tax6_282_rescue))
set(gca,'yTickLabel',{['N=' num2str(length(tax6_282_rescue))]})

subplot(19,2,[19 21])
[activityTable,~] = createNeuralActivityTable(eat16,time,doShift);
imagesc(time,1:length(eat16),activityTable)
caxis([cmin cmax])
title('\it eat-16')
set(gca,'fontSize',fSize)
set(gca,'xTickLabel',{})
set(gca,'yTick',length(eat16))
set(gca,'yTickLabel',{['N=' num2str(length(eat16))]})

subplot(19,2,[23 25])
[activityTable,~] = createNeuralActivityTable(arr1,time,doShift);
imagesc(time,1:length(arr1),activityTable)
caxis([cmin cmax])
title('\it arr-1')
colormap('jet')
set(gca,'xTickLabel',{})
set(gca,'fontSize',fSize)
set(gca,'yTick',length(arr1))
set(gca,'yTickLabel',{['N=' num2str(length(arr1))]})

subplot(19,2,[27 29])
[activityTable,~] = createNeuralActivityTable(grk2,time,doShift);
imagesc(time,1:length(grk2),activityTable)
caxis([cmin cmax]);
title('\it grk-2')
colormap('jet')
set(gca,'fontSize',fSize)
set(gca,'xTickLabel',{})
set(gca,'yTick',length(grk2))
set(gca,'yTickLabel',{['N=' num2str(length(grk2))]})

subplot(19,2,[31 33])
[activityTable,~] = createNeuralActivityTable(odr3,time,doShift);
imagesc(time,1:length(odr3),activityTable)
caxis([cmin cmax])
title('\it odr-3')
colormap('jet')
set(gca,'fontSize',fSize)
set(gca,'xTickLabel',{})
set(gca,'yTick',length(odr3))
set(gca,'yTickLabel',{['N=' num2str(length(odr3))]})

subplot(19,2,[35 37])

[activityTable,~] = createNeuralActivityTable(osm6,time,doShift);
imagesc(time,1:length(osm6),activityTable)
caxis([cmin cmax])
title('\it osm-6')
colormap('jet')
xlabel('Time [s]')
set(gca,'fontSize',fSize)
set(gca,'yTick',length(osm6))
set(gca,'yTickLabel',{['N=' num2str(length(osm6))]})

%normlized ver
cmaxN = 1;
cminN = 0;
doShift = true;
subplot(19,2,[4 6])
[activityTable,~] = createNeuralActivityTable(wt,time,doShift);
for i=1:size(activityTable,1)
    activityTable(i,:) = (activityTable(i,:)-min(activityTable(i,:)))./(max( activityTable(i,:))-min( activityTable(i,:)));
end
imagesc(time,1:length(wt),activityTable)

caxis([cminN cmaxN])

set(gca,'fontSize',fSize)
set(gca,'xTickLabel',{})
set(gca,'yTickLabel',{})

subplot(19,2,[8 10])
[activityTable,~] = createNeuralActivityTable(tax6_486,time,doShift);
for i=1:size(activityTable,1)
    activityTable(i,:) = (activityTable(i,:)-min(activityTable(i,:)))./(max( activityTable(i,:))-min( activityTable(i,:)));
end
imagesc(time,1:length(tax6_486),activityTable)
caxis([cminN cmaxN])
set(gca,'fontSize',fSize)
set(gca,'xTickLabel',{})
set(gca,'yTickLabel',{})

subplot(19,2,[12 14])
[activityTable,~] = createNeuralActivityTable(tax6_282,time,doShift);
for i=1:size(activityTable,1)
    activityTable(i,:) = (activityTable(i,:)-min(activityTable(i,:)))./(max( activityTable(i,:))-min( activityTable(i,:)));
end
imagesc(time,1:length(tax6_282),activityTable)
caxis([cminN cmaxN])
set(gca,'fontSize',fSize)
set(gca,'xTickLabel',{})
set(gca,'yTickLabel',{})

subplot(19,2,[16 18])
[activityTable,~] = createNeuralActivityTable(tax6_282_rescue,time,doShift);
for i=1:size(activityTable,1)
    activityTable(i,:) = (activityTable(i,:)-min(activityTable(i,:)))./(max( activityTable(i,:))-min( activityTable(i,:)));
end
imagesc(time,1:length(tax6_282_rescue),activityTable)
caxis([cminN cmaxN])
set(gca,'fontSize',fSize)
set(gca,'xTickLabel',{})
set(gca,'yTickLabel',{})

subplot(19,2,[20 22])
[activityTable,~] = createNeuralActivityTable(eat16,time,doShift);
for i=1:size(activityTable,1)
    activityTable(i,:) = (activityTable(i,:)-min(activityTable(i,:)))./(max( activityTable(i,:))-min( activityTable(i,:)));
end
imagesc(time,1:length(eat16),activityTable)

caxis([cminN cmaxN])

set(gca,'fontSize',fSize)
set(gca,'xTickLabel',{})
set(gca,'yTickLabel',{})
subplot(19,2,[24 26])

[activityTable,~] = createNeuralActivityTable(arr1,time,doShift);
for i=1:size(activityTable,1)
    activityTable(i,:) = (activityTable(i,:)-min(activityTable(i,:)))./(max( activityTable(i,:))-min( activityTable(i,:)));
end
imagesc(time,1:length(arr1),activityTable)

caxis([cminN cmaxN])

colormap('jet')
set(gca,'xTickLabel',{})


set(gca,'fontSize',fSize)
set(gca,'yTickLabel',{})

subplot(19,2,[28 30])

[activityTable,~] = createNeuralActivityTable(grk2,time,doShift);
for i=1:size(activityTable,1)
    activityTable(i,:) = (activityTable(i,:)-min(activityTable(i,:)))./(max( activityTable(i,:))-min( activityTable(i,:)));
end
imagesc(time,1:length(grk2),activityTable)

caxis([cminN cmaxN])

set(gca,'fontSize',fSize)
set(gca,'xTickLabel',{})
set(gca,'yTickLabel',{})

subplot(19,2,[32 34])

[activityTable,~] = createNeuralActivityTable(odr3,time,doShift);
for i=1:size(activityTable,1)
    activityTable(i,:) = (activityTable(i,:)-min(activityTable(i,:)))./(max( activityTable(i,:))-min( activityTable(i,:)));
end
imagesc(time,1:length(odr3),activityTable)

caxis([cminN cmaxN])

set(gca,'fontSize',fSize)
set(gca,'xTickLabel',{})
set(gca,'yTickLabel',{})

subplot(19,2,[36 38])

[activityTable,~] = createNeuralActivityTable(osm6,time,doShift);
for i=1:size(activityTable,1)
    activityTable(i,:) = (activityTable(i,:)-min(activityTable(i,:)))./(max( activityTable(i,:))-min( activityTable(i,:)));
end
imagesc(time,1:length(osm6),activityTable)

caxis([cminN cmaxN])
xlabel('Time [s]')
set(gca,'fontSize',fSize)
set(gca,'yTickLabel',{})

% Create line
annotation('line',[0.315539739027284 0.314946619217082],...
    [0.110234705228031 0.939933259176863],'LineWidth',2,'LineStyle','--');

% Create line
annotation('line',[0.757413997627522 0.75682087781732],...
    [0.109122358175751 0.938820912124583],'LineWidth',2,'LineStyle','--');

% Create textarrow
annotation('textarrow',[0.612692763938317 0.606168446026099],...
    [0.916686318131257 0.898776418242492],'String',{'gradient start'},...
    'FontWeight','bold',...
    'FontSize',12);

% Create textarrow
annotation('textarrow',[0.167259786476869 0.16073546856465],...
    [0.918911012235818 0.901001112347052],'String',{'gradient start'},...
    'FontWeight','bold',...
    'FontSize',12);
%
figure()
subplot(2,1,1)
h = colorbar;
colormap('jet')
caxis([cmin cmax])
title(h,'\DeltaF/F_0')
set(gca,'fontSize',fSize)
subplot(2,1,2)
h = colorbar;
colormap('jet')
caxis([cminN cmaxN])
title(h,'Normalized activity')
set(gca,'fontSize',fSize)
%% panel c
figure('units','normalized','outerposition',[0 0 1 1])

[activityTable,~] = createNeuralActivityTable(wt,time,doShift);
wtTrace = activityTable(1,:);

[activityTable,~] = createNeuralActivityTable(tax6_282,time,doShift);
tax6_282Trace = activityTable(1,:);

[activityTable,~] = createNeuralActivityTable(tax6_282_rescue,time,doShift);
tax6_282_rescueTrace = activityTable(8,:);


subplot(12,1,1)
plot(time,meanG*DAMToUM(10^-4)*0.8,'black','linewidth',2)
[m, i] = max(diff(meanG));
hold on
set(gca,'fontSize',20)
set(gca,'xTickLabel',{})
set(gca,'yTick',[0, 900])

xlim([min(time),max(time)])
ylabel({'Conc.', '[\muM]'})
subplot(12,1,2:3)
s = plot(time,wtTrace,'lineWidth',1.5,'Color',[0 0.45 0.75]);
hold on
plot(time,tax6_282Trace,'r','LineWidth',1.5)
hold on
% plot(time,tax6_486Trace,'color','#A2142F','LineWidth',2)
plot(time,tax6_282_rescueTrace,'color','#A2142F','LineWidth',1.5)
ylim([-0.1 5])
set(gca,'yTick',[0 2 4])
xlim([min(time) max(time)])
xlabel('Time [s]')
ylabel('\DeltaF/F_0')
%legend('wt','\it tax-6(p675)','\it tax-6(ok2065)')
legend('wt','\it tax-6(p675)','\it tax-6(p675) + AWA::TAX-6')

set(gca,'fontSize',20)
hold off
%% panel d and e
[meanAmp_wt,N_wt] = getPulsesParams(wt,200);
[meanAmp_tax6_282,N_tax6_282] = getPulsesParams(tax6_282,200);
[meanAmp_arr1,N_arr1] = getPulsesParams(arr1,150);
[meanAmp_eat16,N_eat16] = getPulsesParams(eat16,100);
[meanAmp_osm6,N_osm6] = getPulsesParams(osm6,100);
[meanAmp_grk2,N_grk2] = getPulsesParams(grk2,100);
[meanAmp_odr3,N_odr3] = getPulsesParams(odr3,100);
[meanAmp_tax6_486,N_tax6_486] = getPulsesParams(tax6_486,100);
[meanAmp_tax6_282_rescue,N_tax6_282_rescue] = getPulsesParams(tax6_282_rescue,100);


tax6_282Amp = ranksum(meanAmp_wt,meanAmp_tax6_282);
arr1Amp = ranksum(meanAmp_wt,meanAmp_arr1);
eat16Amp = ranksum(meanAmp_wt,meanAmp_eat16);
osm6Amp = ranksum(meanAmp_wt,meanAmp_osm6);
grk2Amp = ranksum(meanAmp_wt,meanAmp_grk2);
odr3Amp = ranksum(meanAmp_wt,meanAmp_odr3);
tax6_486Amp = ranksum(meanAmp_wt,meanAmp_tax6_486);
tax6_282_rescueAmp = ranksum(meanAmp_wt,meanAmp_tax6_282_rescue);

tax6_282_rescue_vs_tax6_282_Amp = ranksum(meanAmp_tax6_282,meanAmp_tax6_282_rescue);
tax6_282_rescue_vs_tax6_486_Amp = ranksum(meanAmp_tax6_486,meanAmp_tax6_282_rescue);


tax6_282N = ranksum(N_wt,N_tax6_282);
arr1N = ranksum(N_wt,N_arr1);
eat16N = ranksum(N_wt,N_eat16);
osm6N = ranksum(N_wt,N_osm6);
grk2N = ranksum(N_wt,N_grk2);
odr3N = ranksum(N_wt,N_odr3);
tax6_486N = ranksum(N_wt,N_tax6_486);
tax6_282_rescueN = ranksum(N_wt,N_tax6_282_rescue);

tax6_282_rescue_vs_tax6_282_N = ranksum(N_tax6_282,N_tax6_282_rescue);
tax6_282_rescue_vs_tax6_486_N = ranksum(N_tax6_486,N_tax6_282_rescue);


allPVals = [tax6_282Amp arr1Amp eat16Amp osm6Amp grk2Amp odr3Amp tax6_486Amp tax6_282_rescueAmp tax6_282_rescue_vs_tax6_282_Amp tax6_282_rescue_vs_tax6_486_Amp...
    tax6_282N arr1N eat16N osm6N grk2N odr3N tax6_486N tax6_282_rescueN tax6_282_rescue_vs_tax6_282_N tax6_282_rescue_vs_tax6_486_N];

corrcetedPV = mafdr(allPVals,'BHFDR',true);

tax6_282Amp = corrcetedPV(1);
arr1Amp = corrcetedPV(2);
eat16Amp = corrcetedPV(3);
osm6Amp = corrcetedPV(4);
grk2Amp = corrcetedPV(5);
odr3Amp = corrcetedPV(6);
tax6_486Amp = corrcetedPV(7);
tax6_282_rescueAmp = corrcetedPV(8);
tax6_282_rescue_vs_tax6_282_Amp = corrcetedPV(9);
tax6_282_rescue_vs_tax6_486_Amp = corrcetedPV(10);

tax6_282N = corrcetedPV(11);
arr1N = corrcetedPV(12);
eat16N = corrcetedPV(13);
osm6N = corrcetedPV(14);
grk2N = corrcetedPV(15) ;
odr3N  = corrcetedPV(16);
tax6_486N  = corrcetedPV(17);
tax6_282_rescueN  = corrcetedPV(18);
tax6_282_rescue_vs_tax6_282_N = corrcetedPV(19);
tax6_282_rescue_vs_tax6_486_N = corrcetedPV(20);

figure('units','normalized','outerposition',[0 0 1 1]);
rng(1)
subplot(1,2,2)
hold on
sep = 4;
plot([-0.5 0.5], [median(meanAmp_wt) median(meanAmp_wt)],'r','lineWidth',3)
scatter((0:(length(meanAmp_wt)-1))/length(meanAmp_wt)-0.5+0,meanAmp_wt,20,'b','filled')
ampPos = 6.5;

curr_sep = sep;
plot([curr_sep-0.5 curr_sep+0.5], [median(meanAmp_tax6_486) median(meanAmp_tax6_486)],'r','lineWidth',3)
scatter((0:(length(meanAmp_tax6_486)-1))/length(meanAmp_tax6_486)-0.5+curr_sep,meanAmp_tax6_486,20,'b','filled')

curr_sep = 2*sep;
plot([curr_sep-0.5 curr_sep+0.5], [median(meanAmp_tax6_282) median(meanAmp_tax6_282)],'r','lineWidth',3)
scatter((0:(length(meanAmp_tax6_282)-1))/length(meanAmp_tax6_282)-0.5+curr_sep,meanAmp_tax6_282,20,'b','filled')

curr_sep = 3*sep;
plot([curr_sep-0.5 curr_sep+0.5], [median(meanAmp_tax6_282_rescue) median(meanAmp_tax6_282_rescue)],'r','lineWidth',3)
scatter((0:(length(meanAmp_tax6_282_rescue)-1))/length(meanAmp_tax6_282_rescue)-0.5+curr_sep,meanAmp_tax6_282_rescue,20,'b','filled')

curr_sep = 4*sep;
plot([curr_sep-0.5 curr_sep+0.5], [median(meanAmp_eat16) median(meanAmp_eat16)],'r','lineWidth',3)
scatter((0:(length(meanAmp_eat16)-1))/length(meanAmp_eat16)-0.5+curr_sep,meanAmp_eat16,20,'b','filled')

curr_sep = 5*sep;
plot([curr_sep-0.5 curr_sep+0.5], [median(meanAmp_arr1) median(meanAmp_arr1)],'r','lineWidth',3)
scatter((0:(length(meanAmp_arr1)-1))/length(meanAmp_arr1)-0.5+curr_sep,meanAmp_arr1,20,'b','filled')

curr_sep = 6*sep;
plot([curr_sep-0.5 curr_sep+0.5], [median(meanAmp_grk2) median(meanAmp_grk2)],'r','lineWidth',3)
scatter((0:(length(meanAmp_grk2)-1))/length(meanAmp_grk2)-0.5+curr_sep,meanAmp_grk2,20,'b','filled')

curr_sep = 7*sep;
plot([curr_sep-0.5 curr_sep+0.5], [median(meanAmp_odr3) median(meanAmp_odr3)],'r','lineWidth',3)
scatter((0:(length(meanAmp_odr3)-1))/length(meanAmp_odr3)-0.5+curr_sep,meanAmp_odr3,20,'b','filled')

curr_sep = 8*sep;
plot([curr_sep-0.5 curr_sep+0.5], [median(meanAmp_osm6) median(meanAmp_osm6)],'r','lineWidth',3)
scatter((0:(length(meanAmp_osm6)-1))/length(meanAmp_osm6)-0.5+curr_sep,meanAmp_osm6,20,'b','filled')

ylabel('Maximal  amplitude [\DeltaF/F_0]')
set(gca,'xTick',[0 sep sep*2 sep*3 sep*4 sep*5 sep*6 sep*7 sep*8])
set(gca,'xTickLabel',{'wt', '\it tax-6(ok2065)', '\it tax-6(p675)','\it tax-6(p675) + AWA::TAX-6','\it eat-16','\it arr-1', '\it grk-2', '\it odr-3','\it osm-6'})
xtickangle(35)
set(gca,'FontSize',18)
xlim([-0.8,sep*8+0.8])
ylim([0 6]); 

subplot(1,2,1)
hold on
sep = 4;
ast_positions = 45;

plot([-0.5 0.5], [median(N_wt) median(N_wt)],'r','lineWidth',3)
scatter((0:(length(N_wt)-1))/length(N_wt)-0.5+0,N_wt,20,'b','filled')

curr_sep = sep;
scatter((0:(length(N_tax6_486)-1))/length(N_tax6_486)-0.5+curr_sep,N_tax6_486,20,'b','filled')
plot([curr_sep-0.5 curr_sep+0.5], [median(N_tax6_486) median(N_tax6_486)],'r','lineWidth',3)

curr_sep = 2*sep;
scatter((0:(length(N_tax6_282)-1))/length(N_tax6_282)-0.5+curr_sep,N_tax6_282,20,'b','filled')
plot([curr_sep-0.5 curr_sep+0.5], [median(N_tax6_282) median(N_tax6_282)],'r','lineWidth',3)

curr_sep = 3*sep;
plot([curr_sep-0.5 curr_sep+0.5], [median(N_tax6_282_rescue) median(N_tax6_282_rescue)],'r','lineWidth',3)
scatter((0:(length(N_tax6_282_rescue)-1))/length(N_tax6_282_rescue)-0.5+curr_sep,N_tax6_282_rescue,20,'b','filled')

curr_sep = 4*sep;
plot([curr_sep-0.5 curr_sep+0.5], [median(N_eat16) median(N_eat16)],'r','lineWidth',3)
scatter((0:(length(N_eat16)-1))/length(N_eat16)-0.5+curr_sep,N_eat16,20,'b','filled')

curr_sep = 5*sep;
plot([curr_sep-0.5 curr_sep+0.5], [median(N_arr1) median(N_arr1)],'r','lineWidth',3)
scatter((0:(length(N_arr1)-1))/length(N_arr1)-0.5+curr_sep,N_arr1,20,'b','filled')

curr_sep = 6*sep;
scatter((0:(length(N_grk2)-1))/length(N_grk2)-0.5+curr_sep,N_grk2,20,'b','filled')
plot([curr_sep-0.5 curr_sep+0.5], [median(N_grk2) median(N_grk2)],'r','lineWidth',3)

curr_sep = 7*sep;
scatter((0:(length(N_odr3)-1))/length(N_odr3)-0.5+curr_sep,N_odr3,20,'b','filled')
plot([curr_sep-0.5 curr_sep+0.5], [median(N_odr3) median(N_odr3)],'r','lineWidth',3)

curr_sep = 8*sep;
plot([curr_sep-0.5 curr_sep+0.5], [median(N_osm6) median(N_osm6)],'r','lineWidth',3)
scatter((0:(length(N_osm6)-1))/length(N_osm6)-0.5+curr_sep,N_osm6,20,'b','filled')

ylabel('Number of pulses')

set(gca,'xTick',[0 sep sep*2 sep*3 sep*4 sep*5 sep*6 sep*7 sep*8])
set(gca,'xTickLabel',{'wt', '\it tax-6(ok2065)', '\it tax-6(p675)','\it tax-6(p675) + AWA::TAX-6','\it eat-16','\it arr-1', '\it grk-2', '\it odr-3','\it osm-6'})
xtickangle(35)
set(gca,'FontSize',18)
xlim([-0.8,sep*8+0.8])
ylim([0 43]); 
%% functions
function [activityTable,allRed] = createNeuralActivityTable(allDatas,time,useCorreted)
    activityTable = zeros(length(allDatas),length(time));
    allRed = zeros(length(allDatas),length(time));
    for i = 1:length(allDatas)
        thisD = allDatas(i);
        thisFlur = thisD.flur;
        thisTime =  thisD.timeInSeconds;

        if useCorreted==1

            thisFlurShift = thisD.flurCorrected;
            thisFlurShift = thisFlurShift-min(thisFlurShift);
        else
            thisFlurShift = thisFlur;
        end
        thisMid = thisD.midGradientTime;
        thisSTime = thisTime-thisMid;
        thisAlignedFlur = interp1(thisSTime,thisFlurShift,time);
        thisAlignedGrad = interp1(thisSTime,thisD.redValuesInTime,time);
        thisAlignedGrad = (thisAlignedGrad-nanmin(thisAlignedGrad))/(nanmax(thisAlignedGrad)-nanmin(thisAlignedGrad));
        activityTable(i,:) = thisAlignedFlur;
        allRed(i,:) = thisAlignedGrad;
    end
end

function [maxAmps,N] = getPulsesParams(allData,dtasrtTime)
    maxAmps = [];
    N = [];
    for i=1:length(allData)
        flur = allData(i).flurCorrected;
        flur = flur;
        time = allData(i).timeInSeconds;
        doPlot=false;
        [peaksInds,peaksVals,~] = detectBursts(flur,time,dtasrtTime,doPlot);

        if isempty(peaksVals)
            peaksInds = zeros(1);
        end
        N = [N length(peaksInds)];
        maxAmps = [maxAmps max(flur)];
    end
end

function [peaksInds,peaksVals,peaksWidths] = detectBursts(flur,time,startTime,doPlot)
    %finds peaks above s that decay at least factpks of height

    factpks = 0.7;
    [pks,locs,widths,proms] = findpeaks(flur);
    startInd = find(time>startTime,1);
    pksShift = [0 pks(1:end-1)];
    cond = proms>pks*factpks & proms>pksShift*factpks  & pks>max(flur)/5 & locs>startInd;
    peaksInds = locs(cond);
    peaksVals = pks(cond);
    peaksWidths = widths(cond);

    if doPlot==1
        plot(time,flur)
        hold on
        plot(time(peaksInds),peaksVals,'r*')
        w = waitforbuttonpress;
    end
end