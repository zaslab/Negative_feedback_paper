%% simulation
%WT first step long
[t1 , Ca1, L1, m1] = GPCR_negative_feedback_simulation('ez',true,'show_output',false,'time_track',false,...
           'gradType',7,'t_end',440000,'ts',30000,'tf',410000,'amplitude',DAMToUM(10^-4),...
           'step_duration', 300000, 'break_duration', 60000);          

%WT first step short
[t2 , Ca2, L2, m2] = GPCR_negative_feedback_simulation('ez',true,'show_output',false,'time_track',false,...
           'gradType',7,'t_end',440000,'ts',30000,'tf',410000,'amplitude',DAMToUM(10^-4),...
           'step_duration', 60000, 'break_duration', 300000);  

%tax6 first step long
[t3 , Ca3, L3, m3] = GPCR_negative_feedback_simulation('ez',true,'show_output',false,'time_track',false,...
           'gradType',7,'t_end',440000,'ts',30000,'tf',410000,'amplitude',DAMToUM(10^-4),...
           'step_duration', 300000, 'break_duration', 60000,'calcium_dependent_inhibition_coeff',0);
%WT tanh
[t4 , Ca4, L4, m4] = GPCR_negative_feedback_simulation('ez',true,'show_output',false,'time_track',false,...
           'gradType',3,'t_end',840000,'ts',0,'tf',840000,'amplitude',DAMToUM(10^-4)/3);          
       
%tax6 tanh
[t5 , Ca5, L5, m5] = GPCR_negative_feedback_simulation('ez',true,'show_output',false,'time_track',false,...
           'gradType',3,'t_end',840000,'ts',0,'tf',840000,'amplitude',DAMToUM(10^-4)/3,'calcium_dependent_inhibition_coeff',0);          
%% panels a,b,c
t1_sync = t1 - 30000;
t2_sync = t2 - 30000;
t3_sync = t3 - 30000;
t4_sync = t4 - (840000 + 0)/2;
t5_sync = t5 - (840000 + 0)/2;

figure(); 

subplot(12,3,[1 4]);
plot(t4_sync/1000,L4*10^-3,'LineWidth', 1.5, 'Color', 'k');
ylabel({'Ligand' , '[mM]'});
ylim([-0.2*max(L4*10^-3),1.2*max(L4*10^-3)]);
xlim([min(t4_sync/1000) max(t4_sync/1000)])
set(gca,'YTick',[0 0.8]);
set(gca,'FontSize',20);
set(gca,'XTickLabel',[]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';

subplot(12,3,[7 10 13 16 19]);
plot(t5_sync/1000,Ca5*10^6,'LineWidth', 1.5, 'Color','r');
hold on;
plot(t4_sync/1000,Ca4*10^6,'LineWidth', 1.5, 'Color', 'b'); 
ylabel({'Calcium','Conc. [\muM]'});
ylim([-0.05*max(Ca5*10^6),1.05*max(Ca5*10^6)]);
xlim([min(t4_sync/1000) max(t4_sync/1000)])
legend('{\it tax-6}','wt')
set(gca,'FontSize',20);
set(gca,'XTickLabel',[]);
set(gca,'YTick',[0 250 500]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';

subplot(12,3,[22 25 28 31 34]);
plot(t5_sync/1000,m5,'LineWidth', 1.5, 'Color','r');
hold on;
plot(t4_sync/1000,m4,'LineWidth', 1.5, 'Color','b'); 
ylim([-0.03*max(m1),1.03*max(m1)]); 
ylabel('Inhibition');
xlim([min(t4_sync/1000) max(t4_sync/1000)])
set(gca,'YTick',[0 3 6]);
set(gca,'FontSize',20);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';
xlabel('Time [sec]');

subplot(12,3,[2 5]);
plot(t1_sync/1000,L1*10^-3,'LineWidth', 1.5, 'Color', 'k'); 
ylim([-0.2*max(L1*10^-3),1.2*max(L1*10^-3)]);
xlim([min(t1_sync/1000) max(t1_sync/1000)])
set(gca,'FontSize',20);
set(gca,'XTickLabel',[]);
set(gca,'YTick',[0 1]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';

subplot(12,3,[8 11 14 17 20]);
plot(t3_sync/1000,Ca3*10^6,'LineWidth', 1.5, 'Color', 'r');
hold on;
plot(t1_sync/1000,Ca1*10^6,'LineWidth', 1.5, 'Color', 'b'); 
ylim([-0.05*max(Ca3*10^6),1.05*max(Ca3*10^6)]);
xlim([min(t1_sync/1000) max(t1_sync/1000)])
legend('{\it tax-6}','wt')
set(gca,'FontSize',20);
set(gca,'XTickLabel',[]);
set(gca,'YTick',[0 250 500]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';

subplot(12,3,[23 26 29 32 35]);
plot(t3_sync/1000,m3,'LineWidth', 1.5, 'Color','r');
hold on;
plot(t1_sync/1000,m1,'LineWidth', 1.5, 'Color','b'); 
ylim([-0.03*max(m1),1.03*max(m1)]); 
xlim([min(t3_sync/1000) max(t3/1000)])
set(gca,'YTick',[0 3 6]);
set(gca,'FontSize',20);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';
xlabel('Time [sec]');

subplot(12,3,[3 6]);
plot(t2_sync/1000,L2*10^-3,'LineWidth', 1.5,'LineStyle','--', 'Color', 'k'); hold on; 
plot(t1_sync/1000,L1*10^-3,'LineWidth', 1.5, 'Color', 'k'); 
ylim([-0.2*max(L2*10^-3),1.2*max(L2*10^-3)]);
xlim([min(t2_sync/1000) max(t2_sync/1000)])
set(gca,'FontSize',20);
set(gca,'XTickLabel',[]);
set(gca,'YTick',[0 1]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';

subplot(12,3,[9 12 15 18 21]);
plot(t2_sync/1000,Ca2*10^6,'LineWidth', 1.5, 'Color', 'm'); hold on; 
plot(t1_sync/1000,Ca1*10^6,'LineWidth', 1.5, 'Color', 'b'); 
ylim([-0.05*max(Ca3*10^6),1.05*max(Ca3*10^6)]);
xlim([min(t2_sync/1000) max(t2_sync/1000)])
set(gca,'FontSize',20);
set(gca,'XTickLabel',[]);
set(gca,'YTick',[0 250 500]);
legend('wt short-step','wt long-step');
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';

subplot(12,3,[24 27 30 33 36]);
plot(t2_sync/1000,m2,'LineWidth', 1.5, 'Color' , 'm'); hold on; 
plot(t1_sync/1000,m1,'LineWidth', 1.5, 'Color','b'); 
ylim([-0.03*max(m1),1.03*max(m1)]); 
xlim([min(t2_sync/1000) max(t2_sync/1000)])
set(gca,'YTick',[0 3 6]);
set(gca,'FontSize',20);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';
xlabel('Time [sec]');

% Create line
annotation('line',[0.411420204978038 0.623718887262079],...
    [0.702330261136713 0.702330261136713],'Color',[0 0 1],'LineStyle','--');

% Create line
annotation('line',[0.691068814055638 0.903367496339679],...
    [0.702330261136713 0.702330261136713],'Color',[0 0 1],'LineStyle','--');

% Create line
annotation('line',[0.236572710144096 0.236456808199122],...
    [0.925556911531666 0.463901689708141],...
    'Color',[0.501960784313725 0.501960784313725 0.501960784313725],...
    'LineWidth',2,...
    'LineStyle','--');
          