%% general
load('Figure_4_data.mat')

fontS = 22;

maxTime =  440;
minTime = -8;
dInterpolated = 0.3;
interppolatedTime = [minTime:dInterpolated:maxTime];
oneFiveIntMat = [];

for i = 1:length(wormsStepsData)
    thisF = wormsStepsData(i).flurCorrected;
    thisT  = wormsStepsData(i).timeCorrected;
    intFlur = interp1(thisT,thisF,interppolatedTime);
    oneFiveIntMat(i,:) = intFlur;
    wormsStepsData(i).intTime = interppolatedTime;
    wormsStepsData(i).intFlur = intFlur;
end
wormsStepsDataTbl = struct2table(wormsStepsData);
wormsStepsDataTbl.strain = categorical(wormsStepsDataTbl.strain);
%% panel a
fontS = 22;

TIME_BEFORE_PEAK1 = 10;
TIME_AFTER_PEAK1 = 350;
maxF = 8;
TIME_BEFORE_PEAK2 = 5;
TIME_AFTER_PEAK2 = 5;
iterpolationDt = interppolatedTime(2)-interppolatedTime(1);
indsAfterPeak = floor(TIME_AFTER_PEAK2/iterpolationDt);
indsBeforePeak = floor(TIME_BEFORE_PEAK2/iterpolationDt);
p1Time = interppolatedTime(interppolatedTime>-1*TIME_BEFORE_PEAK1 & interppolatedTime < TIME_AFTER_PEAK1);
p1Flur = oneFiveIntMat(:,interppolatedTime>-1*TIME_BEFORE_PEAK1 & interppolatedTime < TIME_AFTER_PEAK1);
p1Flur(p1Flur>maxF)=maxF;
p2Time = [-1*TIME_BEFORE_PEAK2:iterpolationDt:TIME_AFTER_PEAK2];
p2Flur = [];
intReds = [];
p2Red = [];
for i=1:length(wormsStepsData)
    intReds(i,:) = interp1(wormsStepsData(i).timeCorrected,wormsStepsData(i).redValuesInTime,wormsStepsData(i).intTime);
    intReds(i,:) = (intReds(i,:)-min(intReds(i,:)))/(max(intReds(i,:))-min(intReds(i,:)));
end

for i=1:length(wormsStepsData)
    thisPeak2Time = wormsStepsData(i).timeCorrected(wormsStepsData(i).peakInds(2));
    [~, thisPeak2Ind] = min(abs(interppolatedTime-thisPeak2Time));
    p2Flur(i,:) = wormsStepsData(i).intFlur(thisPeak2Ind-indsBeforePeak:thisPeak2Ind+indsAfterPeak);
    p2Red(i,:) = intReds(i,thisPeak2Ind-indsBeforePeak:thisPeak2Ind+indsAfterPeak);
    
end
p2Flur(p2Flur>maxF)=maxF;
bottom = min(min(p2Flur));
top = max(max(p1Flur));
figure('units','normalized','outerposition',[0 0 1 1])

subplot(14,4,17:19)
step5 = zeros(length(p1Time),1);
step5(p1Time>-1 & p1Time<5*60-1) = 1;
plot(p1Time,step5,'r','LineWidth',3)
set(gca,'XTick', [])
set(gca,'XTickLabel', {})
yticks([0 1])
yticklabels({'0.1 \muM','1.1 mM'})
xlim([min(p1Time),max(p1Time)])
ylim([-0.2, max(step5)*1.2])
set(gca,'FontSize',fontS)

subplot(14,4,20) 
secondStep = ones(length(p2Time),1);
secondStep(p2Time<0-0.3*9) = 0;
plot([p2Time(secondStep == 0) max(p2Time(secondStep == 0))  p2Time(secondStep == 1)],[secondStep(secondStep == 0) ; 1 ; secondStep(secondStep == 1)],'r','LineWidth',3)
ylim([-0.2, max(step5)*1.2])
set(gca,'XTick', [])
set(gca,'YTick', [])

subplot(14,4,4) 
secondStep = ones(length(p2Time),1);
secondStep(p2Time<0-0.3*9) = 0;
plot([p2Time(secondStep == 0) max(p2Time(secondStep == 0))  p2Time(secondStep == 1)],[secondStep(secondStep == 0) ; 1 ; secondStep(secondStep == 1)],'r','LineWidth',3)
ylim([-0.2, max(step5)*1.2])
set(gca,'XTick', [])
set(gca,'YTick', [])
title('second step');
set(gca,'FontSize',fontS)

subplot(14,4,1:3)
step1 = zeros(length(p1Time),1);
step1(p1Time>-1 & p1Time<1*60-1) = 1;
plot(p1Time,step1,'r','LineWidth',3)
set(gca,'XTickLabel', {})
set(gca,'XTick', [])
yticks([0 1])
yticklabels({'0.1 \muM','1.1 mM'})
xlim([min(p1Time),max(p1Time)])
ylim([-0.2, max(step5)*1.2])
title('first step');
set(gca,'FontSize',fontS)

subplot(14,4,[5 6 7 9 10 11 13 14 15])
n1WT = size(p1Flur(wormsStepsDataTbl.strain=='wt' & wormsStepsDataTbl.stepDuration==1,:),1);
imagesc(p1Time,1:n1WT, p1Flur(wormsStepsDataTbl.strain=='wt' & wormsStepsDataTbl.stepDuration==1,:))
ylabel('wt','fontweight','bold')
set(gca,'FontSize',fontS)
caxis manual
caxis([bottom top]);
set(gca,'XTickLabel', {})
set(gca,'YTick', n1WT)
set(gca,'YTickLabel',['N = ' num2str(n1WT)]);

subplot(14,4,[8 12 16])
imagesc(p2Time,1:n1WT, p2Flur(wormsStepsDataTbl.strain=='wt' & wormsStepsDataTbl.stepDuration==1,:))
set(gca,'FontSize',fontS)
caxis manual
caxis([bottom top]);
set(gca,'XTickLabel', {})
set(gca,'YTickLabel', {})

n5WT = size(p1Flur(wormsStepsDataTbl.strain=='wt' & wormsStepsDataTbl.stepDuration==5,:),1);
subplot(14,4,[21:23 25:27 29:31])
imagesc(p1Time,1:n5WT,p1Flur(wormsStepsDataTbl.strain=='wt' & wormsStepsDataTbl.stepDuration==5,:))
ylabel('wt','fontweight','bold')
set(gca,'FontSize',fontS)
set(gca,'XTickLabel', {})
set(gca,'YTick', n5WT)
set(gca,'YTickLabel',['N = ' num2str(n5WT)]);
caxis manual
caxis([bottom top]);

n5WT = size(p1Flur(wormsStepsDataTbl.strain=='wt' & wormsStepsDataTbl.stepDuration==5,:),1);
subplot(14,4,[24 28 32])
imagesc(p2Time,1:n5WT, p2Flur(wormsStepsDataTbl.strain=='wt' & wormsStepsDataTbl.stepDuration==5,:))
set(gca,'FontSize',fontS)
caxis manual
caxis([bottom top]);
set(gca,'XTickLabel', {})
set(gca,'YTickLabel', {})

n5Tax6 = size(p1Flur(wormsStepsDataTbl.strain=='tax6' & wormsStepsDataTbl.stepDuration==5,:),1);
subplot(14,4,[33:35 37:39 41:43])
imagesc(p1Time,1:n5Tax6,p1Flur(wormsStepsDataTbl.strain=='tax6' & wormsStepsDataTbl.stepDuration==5,:))
set(gca,'YTick', n5Tax6)
set(gca,'YTickLabel',['N = ' num2str(n5Tax6)]);
set(gca,'XTickLabel', {})
ylabel('\it tax-6(p675)','fontweight','bold')
set(gca,'FontSize',fontS)
caxis manual
caxis([bottom top]);

subplot(14,4,[36 40 44])
imagesc(p2Time,1:n5Tax6,p2Flur(wormsStepsDataTbl.strain=='tax6' & wormsStepsDataTbl.stepDuration==5,:))
set(gca,'FontSize',fontS)
set(gca,'YTickLabel', {})
set(gca,'YTick', n5Tax6)
set(gca,'XTickLabel', {})
caxis manual
caxis([bottom top]);

n5Tax6rescue = size(p1Flur(wormsStepsDataTbl.strain=='tax6rescue' & wormsStepsDataTbl.stepDuration==5,:),1);
subplot(14,4,[45:47 49:51 53:55])
imagesc(p1Time,1:n5Tax6rescue,p1Flur(wormsStepsDataTbl.strain=='tax6rescue' & wormsStepsDataTbl.stepDuration==5,:))
set(gca,'YTick', n5Tax6rescue)
set(gca,'YTickLabel',['N = ' num2str(n5Tax6rescue)]);
ylabel({'\it tax-6(p675) +','AWA::TAX-6'},'fontweight','bold')
xlabel('Time [sec]')
set(gca,'FontSize',fontS)
caxis manual
caxis([bottom top]);

subplot(14,4,[48 52 56])
imagesc(p2Time,1:n5Tax6rescue,p2Flur(wormsStepsDataTbl.strain=='tax6rescue' & wormsStepsDataTbl.stepDuration==5,:))
set(gca,'FontSize',fontS)
caxis manual
caxis([bottom top]);
xlabel('Time [sec]')
set(gca,'YTick',[])

colormap('jet')

figure();
subplot(4,4,1);
colormap('jet')
cbh = colorbar('XTickLabel',{'0','2','4','6','>8'}, ...
               'XTick', [0,2,4,6,8]);
cbh.Location = 'northoutside';
cbh.Position(4) = 5*cbh.Position(4);
set(gca,'FontSize',fontS)
title(cbh,'\DeltaF/F_0')
caxis manual
caxis([bottom top]);
%% detects transients, normalize them and fit decay
TIME_BEFORE_PEAK1 = 10;
TIME_AFTER_PEAK1 = 60;

%Non-normalized responses
iterpolationDt = interppolatedTime(2)-interppolatedTime(1);
p1Time = interppolatedTime(interppolatedTime>-1*TIME_BEFORE_PEAK1 & interppolatedTime < TIME_AFTER_PEAK1);
p1Flur = oneFiveIntMat(:,interppolatedTime>-1*TIME_BEFORE_PEAK1 & interppolatedTime < TIME_AFTER_PEAK1);

figure('units','normalized','outerposition',[0 0 1 1])
subplot(2,2,1)
plot(p1Time,p1Flur(wormsStepsDataTbl.strain=='wt' & wormsStepsDataTbl.stepDuration==5,:),'Color',[0.7 0.7 1]);
hold on
plot(p1Time,median(p1Flur(wormsStepsDataTbl.strain == 'wt' & wormsStepsDataTbl.stepDuration==5,:)),'b','LineWidth',5);

plot(p1Time,p1Flur(wormsStepsDataTbl.strain=='tax6' & wormsStepsDataTbl.stepDuration==5,:),'Color',[1 0.7 0.7]);
plot(p1Time,median(p1Flur(wormsStepsDataTbl.strain=='tax6' & wormsStepsDataTbl.stepDuration==5,:)),'r','LineWidth',5);

plot(p1Time,p1Flur(wormsStepsDataTbl.strain=='tax6rescue' & wormsStepsDataTbl.stepDuration==5,:),'Color','k');
plot(p1Time,median(p1Flur(wormsStepsDataTbl.strain=='tax6rescue' & wormsStepsDataTbl.stepDuration==5,:)),'k','LineWidth',5);


legend('wt','tax-6','tax-6 rescue')
xlabel('Time [s]')
ylabel('\DeltaF/F_0')
xlim([-10 60])
set(gca,'FontSize',fontS)

% normalized responses
subplot(2,2,2)
WT_Cols = winter(n5WT);
plotFs = p1Flur(wormsStepsDataTbl.strain=='wt' & wormsStepsDataTbl.stepDuration==5,:);
hold on
fitNormParams5MinWT_P1 = nan(n5WT,3);
for i=1:n5WT
    plotFsN_WT(i,:) = plotFs(i,:)/max(plotFs(i,:));
    
    if min(plotFsN_WT(i,:))>-0.5
        plot(p1Time,plotFsN_WT(i,:),'Color',[0.7 0.7 1])
        fitNormParams5MinWT_P1(i,:) = fitNormSinglePulse(p1Time,plotFsN_WT(i,:),20,i);
    else
        disp(i)
    end
end
medWT_N = median(plotFsN_WT);
plot(p1Time,medWT_N,'b','LineWidth',5)

Tax6Cols = autumn(n5Tax6);
plotFs = p1Flur(wormsStepsDataTbl.strain=='tax6' & wormsStepsDataTbl.stepDuration==5,:);
hold on
fitNormParams5MinTax6P1 = nan(n5Tax6,3);
for i=1:n5Tax6
    plotFsNTax6(i,:) = plotFs(i,:)/max(plotFs(i,:));
    
    if min(plotFsNTax6(i,:))>-0.1
        fitNormParams5MinTax6P1(i,:) = fitNormSinglePulse(p1Time,plotFsNTax6(i,:),20,i);
        plot(p1Time,plotFsNTax6(i,:),'Color',[1 0.7 0.7])
    end
end
medTax6 = median(plotFsNTax6);
plot(p1Time,medTax6,'r','LineWidth',5)


Tax6rescueCols = autumn(n5Tax6rescue);
plotFs = p1Flur(wormsStepsDataTbl.strain=='tax6rescue' & wormsStepsDataTbl.stepDuration==5,:);
hold on
fitNormParams5MinTax6rescueP1 = nan(n5Tax6rescue,3);
for i=1:n5Tax6rescue
    plotFsNTax6rescue(i,:) = plotFs(i,:)/max(plotFs(i,:));
    
    if min(plotFsNTax6rescue(i,:))>-0.1
        fitNormParams5MinTax6rescueP1(i,:) = fitNormSinglePulse(p1Time,plotFsNTax6rescue(i,:),20,i);
        plot(p1Time,plotFsNTax6rescue(i,:),'Color','k')
    end
end
medTax6rescue = median(plotFsNTax6rescue);
plot(p1Time,medTax6rescue,'k','LineWidth',5)

ylim([-0.2 1.2])
xlabel('Time [s]')
ylabel('Normalized amplitude')
set(gca,'FontSize',fontS+5)

xlim([-10 60])
close all;

for i=1:height(wormsStepsDataTbl)
  thisPs = wormsStepsDataTbl.peakInds(i);
  thisPs = thisPs{1};
  thisF = wormsStepsDataTbl.flurCorrected(i);
  thisF = thisF{1};
  allP1(i) = thisF(thisPs(1));
  allP2(i) = thisF(thisPs(2));
end
wormsStepsDataTbl.allP1 = allP1';
wormsStepsDataTbl.allP2 = allP2';

aFirstL = wormsStepsDataTbl.allP1(wormsStepsDataTbl.strain=='wt' & wormsStepsDataTbl.stepDuration==5);
aFirstT = wormsStepsDataTbl.allP1(wormsStepsDataTbl.strain=='tax6' & wormsStepsDataTbl.stepDuration==5);
aFirstTrescue = wormsStepsDataTbl.allP1(wormsStepsDataTbl.strain=='tax6rescue' & wormsStepsDataTbl.stepDuration==5);
aFirstShort = wormsStepsDataTbl.allP1(wormsStepsDataTbl.strain=='wt' & wormsStepsDataTbl.stepDuration==1);

aSecondL =  wormsStepsDataTbl.allP2(wormsStepsDataTbl.strain=='wt' & wormsStepsDataTbl.stepDuration==5);
aSecondT = wormsStepsDataTbl.allP2(wormsStepsDataTbl.strain=='tax6' & wormsStepsDataTbl.stepDuration==5);
aSecondTrescue = wormsStepsDataTbl.allP2(wormsStepsDataTbl.strain=='tax6rescue' & wormsStepsDataTbl.stepDuration==5);
aSecondShort = wormsStepsDataTbl.allP2(wormsStepsDataTbl.strain=='wt' & wormsStepsDataTbl.stepDuration==1);
%% statistical test for panel a
disp('comapre response amplitude of wt to the second step between long and short protocols')
ranksum(aSecondL,aSecondShort)
%% panel b and c
figure('units','normalized','outerposition',[0 0 1 1])

subplot(2,2,1)

shadedErrorBar(p1Time,nanmedian(p1Flur(wormsStepsDataTbl.strain=='wt' & wormsStepsDataTbl.stepDuration==5,:)),mad(p1Flur(wormsStepsDataTbl.strain=='wt' & wormsStepsDataTbl.stepDuration==5,:),1),'blue',1)
hold on
shadedErrorBar(p1Time,nanmedian(p1Flur(wormsStepsDataTbl.strain=='tax6' & wormsStepsDataTbl.stepDuration==5,:)),mad(p1Flur(wormsStepsDataTbl.strain=='tax6' & wormsStepsDataTbl.stepDuration==5,:),1),'red',1)
hold on
shadedErrorBar(p1Time,nanmedian(p1Flur(wormsStepsDataTbl.strain=='tax6rescue' & wormsStepsDataTbl.stepDuration==5,:)),mad(p1Flur(wormsStepsDataTbl.strain=='tax6rescue' & wormsStepsDataTbl.stepDuration==5,:),1),'black',1)
ylim([-0.2 7.2])
legend2 = legend('wt','','','','tax-6(p675)','','','','tax-6(p675) + AWA::TAX-6');
set(legend2,'FontAngle','italic','FontSize',16);
xlim([min(p1Time), max(p1Time)])
xlabel('Time [s]')
ylabel({'Neural response', '[\DeltaF/F_0]'})
set(gca,'FontSize',16)

xticks([0:10:50]);

subplot(2,2,2)

shadedErrorBar(p1Time,nanmean(plotFsN_WT),mad(plotFsN_WT),'blue',1)
hold on
shadedErrorBar(p1Time,nanmean(plotFsNTax6),mad(plotFsNTax6),'red',1)
hold on
shadedErrorBar(p1Time,nanmean(plotFsNTax6rescue),mad(plotFsNTax6rescue),'black',1)
ylim([-0.1 1.1])
xlim([min(p1Time), max(p1Time)])
xlabel('Time [s]')
ylabel({'Normalized response', '[\DeltaF/F_0]'})
set(gca,'FontSize',16)
xticks([0:10:50]);
legend2 = legend('wt','','','','tax-6(p675)','','','','tax-6(p675) + AWA::TAX-6');
set(legend2,'FontAngle','italic','FontSize',16);


disp('decay times for normalized response for first step:')
disp('wt:')
median(fitNormParams5MinWT_P1(:,2))
disp('tax-6:')
median(fitNormParams5MinTax6P1(:,2))
disp('tax-6 rescue:')
median(fitNormParams5MinTax6rescueP1(:,2))

disp('compare decay times between wt and tax-6')
ranksum(fitNormParams5MinWT_P1(:,2),fitNormParams5MinTax6P1(:,2))
disp('compare decay times between wt and tax-6 rescue')
ranksum(fitNormParams5MinWT_P1(:,2),fitNormParams5MinTax6rescueP1(:,2))
disp('compare decay times between tax-6 and tax-6 rescue')
ranksum(fitNormParams5MinTax6P1(:,2),fitNormParams5MinTax6rescueP1(:,2))
%% panel d and e

subplot(2,2,3)

h1 = plot([zeros(length(aFirstL),1),ones(length(aFirstL),1)]',[aFirstL aSecondL]','b.-','MarkerSize',25);
hold on
h2 = plot([ones(length(aFirstT),1)*2,ones(length(aFirstT),1)*3]',[aFirstT aSecondT]','r.-','MarkerSize',25);
hold on
h3 = plot([ones(length(aFirstTrescue),1)*4,ones(length(aFirstTrescue),1)*5]',[aFirstTrescue aSecondTrescue]','k.-','MarkerSize',25);


h4 = plot([-0.25 0.25],[median(aFirstL),median(aFirstL)],'black','LineWidth',4);
plot([0.75 1.25],[median(aSecondL),median(aSecondL)],'black','LineWidth',4)
plot([1.75 2.25],[median(aFirstT),median(aFirstT)],'black','LineWidth',4)
plot([2.75 3.25],[median(aSecondT),median(aSecondT)],'black','LineWidth',4)
plot([3.75 4.25],[median(aFirstTrescue),median(aFirstTrescue)],'black','LineWidth',4)
plot([4.75 5.25],[median(aSecondTrescue),median(aSecondTrescue)],'black','LineWidth',4)


set(gca,'XTick',[0:1:5])
xlim([-0.5, 5.5])
set(gca,'XTickLabel',{'1^{st}','2^{nd}','1^{st}','2^{nd}','1^{st}','2^{nd}'})
xlabel('step number');
ylabel({'Response  amplitude' , '[\DeltaF/F_0]'})
set(gca,'FontSize',16)
legend([h1(1) h2(1) h3(1) h4(1)],{'wt','\it tax-6(p675)','\it tax-6(p675) + AWA::TAX-6'},'Location','northwest')

disp('wt compare first and second pulse')
signrank(aSecondL,aFirstL)
disp('tax-6 compare first and second pulse')
signrank(aSecondT,aFirstT)
disp('tax-6 rescue compare first and second pulse')
signrank(aSecondTrescue,aFirstTrescue)

disp('compare first pulse between wt and tax-6')
ranksum(aFirstT,aFirstL)
disp('compare second pulse between wt and tax-6')
ranksum(aSecondT,aSecondL)


subplot(2,2,4)
scatter(aFirstL,(aFirstL-aSecondL),45,'b','filled')
hold on
scatter(aFirstT,aFirstT-aSecondT,45,'r','filled')
hold on
scatter(aFirstTrescue,aFirstTrescue-aSecondTrescue,45,'k','filled')

axis equal
set(gca,'XTick',0:2:10)

Pl = polyfit(aFirstL,aFirstL-aSecondL,1);
x0 = min(aFirstL) ; x1 = max(aFirstL) ;
xi = [x0 x1];
yi = Pl(1)*xi+Pl(2);
plot([x0 x1], yi,'b--')

Pt = polyfit(aFirstT,aFirstT-aSecondT,1);
x0 = min(aFirstT) ; x1 = max(aFirstT) ;
xi = [x0 x1];
yi = Pt(1)*xi+Pt(2);
plot([x0 x1], yi,'r--')

Pt = polyfit(aFirstTrescue,aFirstTrescue-aSecondTrescue,1);
x0 = min(aFirstTrescue) ; x1 = max(aFirstTrescue) ;
xi = [x0 x1];
yi = Pt(1)*xi+Pt(2);
plot([x0 x1], yi,'k--')

ylabel('A_1 - A_2 [\DeltaF/F_0]')
xlabel('A_1 [\DeltaF/F_0]')
set(gca,'fontSize',16)
legend('wt','\it tax-6(p675)','\it tax-6(p675) + AWA::TAX-6','Location','northwest')

disp('test corelation for wt')
[c, p] =  corrcoef(aFirstL,aFirstL-aSecondL);
PvalCorrN2 = p(2)
correlationN2 = c(2)

disp('test corelation for tax-6')
[c, p] =  corrcoef(aFirstT,aFirstT-aSecondT);
PvalCorrTax6 = p(2)
correlationTax6 = c(2)

disp('test corelation for tax-6 rescue')
[c, p] =  corrcoef(aFirstTrescue,aFirstTrescue-aSecondTrescue);
PvalCorrTax6rescue = p(2)
correlationTax6rescue = c(2)
%% functions
function [fitParams] = fitNormSinglePulse(timeSec,flur,expFitTime,ind)
    if  ~exist('expFitTime','var')
        expFitTime = 20; %second;
    end

    if  ~exist('ind','var')
        ind = 1; %second;
    end

    startTimeFromPeak = 2;

    [~, peakIndex] = max(flur);

    dt = timeSec(2) - timeSec(1); 
    startIndex = peakIndex + ceil(startTimeFromPeak/dt);
    endIndex = peakIndex + ceil(expFitTime/dt);

    fitFlur = flur(startIndex:endIndex);
    fitFlur = (fitFlur-min(fitFlur))/(max(fitFlur)-min(fitFlur));
    fitTime = 0:dt:dt*(length(fitFlur)-1);

    ft = fittype( 'a*exp(-x/b)+c', 'independent', 'x', 'dependent', 'y' );
    opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
    opts.Display = 'Off';
    opts.Lower = [0 0.01 -0.5];
    opts.Upper = [3 100 0.5];
    [fitresult, gof] = fit( fitTime', fitFlur', ft, opts );

    figure( 'Name', 'untitled fit 1' );
    subplot(1,2,1);
    plot( fitresult, fitTime, fitFlur );
    xlabel x; ylabel y; grid on
    subplot(1,2,2);
    plot(timeSec,flur,'MarkerSize', 14);
    hold on
    plot(timeSec(startIndex:endIndex),ones(length(startIndex:endIndex),1),'LineWidth',5)
    grid on;
    title(['step num in ind ' num2str(ind)])
    %waitforbuttonpress;
    close gcf;

    fitParams = [fitresult.a, fitresult.b, fitresult.c] ;
end