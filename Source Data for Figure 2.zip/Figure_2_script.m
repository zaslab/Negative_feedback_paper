%% simulation and upload experimental data
% step
[t1, Ca1, L1, m1, a1] = GPCR_negative_feedback_simulation('ez',true,'model_type',1,'time_track',false,...
    'gradType',2,'t_end',450000,'ts',30000,'tf',330000,'amplitude',DAMToUM(10^-4));  

%tanh
[t2, Ca2, L2, m2, a2] = GPCR_negative_feedback_simulation('ez',true,'model_type',1,'time_track',false,...
           'gradType',3,'t_end',1020000,'ts',100000,'tf',1020000,'amplitude',DAMToUM(10^-4)/2*0.7);  

load('Figure_2_experimental_data.mat')
close all;
%% panel a
figure();

time_exp = wt_step.timeInSeconds{1,1} - 30; 
flur_exp = wt_step.flurCorrected{1,1};
t1_plot = t1 - 30000;

subplot(12,2,[1 3]);
plot(t1_plot/1000,L1*10^-3,'LineWidth', 1.5, 'Color', 'k'); 
ylabel({'Ligand' , '[mM]'});
ylim([-0.2*max(L1*10^-3),1.2*max(L1*10^-3)]);
xlim([min(t1_plot/1000) max(t1_plot/1000)]);
set(gca,'FontSize',20);
set(gca,'XTickLabel',[]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';
set(gca,'YTick',[0 1]);

subplot(12,2,[9 11 13]);
plot(time_exp,flur_exp,'LineWidth', 1.5, 'Color', 'b')
xlim([min(t1_plot/1000) max(t1_plot/1000)]);
ylim([-0.1*max(flur_exp),1.1*max(flur_exp)]);
ylabel('\DeltaF/F_0');
set(gca,'FontSize',20);
set(gca,'XTickLabel',[]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';
set(gca,'YTick',[0 4]);


subplot(12,2,[15 17 19]);
plot(t1_plot/1000,Ca1*10^6,'LineWidth', 1.5, 'Color', 'b'); 
ylabel({'Calcium', 'conc. [\muM]'});
ylim([-0.1*max(Ca1*10^6),1.1*max(Ca1*10^6)]);
xlim([min(t1_plot/1000) max(t1_plot/1000)]);
set(gca,'FontSize',20);
set(gca,'XTickLabel',[]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';
set(gca,'YTick',[0 300]);


subplot(12,2,[21 23]); 
yyaxis right; plot(t1_plot/1000,m1,'LineWidth', 1.5); 
ylabel('Inhibition');
ylim([-0.03*max(m1),1.03*max(m1)]);
yyaxis left; plot(t1_plot/1000,a1,'LineWidth', 1.5);
ylabel({'Receptor','activation'});
ylim([-0.05,1.05]);
xlabel('Time [Sec]');
xlim([min(t1_plot/1000) max(t1_plot/1000)]);
set(gca,'FontSize',20);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';       
yyaxis left; set(gca,'YTick',[0 1]);
yyaxis right; set(gca,'YTick',[0 6]);         
%% panel b
hold on;

time_exp2 = wt_tanh(1).timeInSeconds - 605.46; 
flur_exp2 = wt_tanh(1).flurCorrected;
red_exp2 = (wt_tanh(1).redValuesInTime - min(wt_tanh(1).redValuesInTime))./ (max(wt_tanh(1).redValuesInTime) - min(wt_tanh(1).redValuesInTime)); 
t2_plot = t2 - (1020000 + 100000)/2;
t_start_plot = -550;
t_end_plot = 350;

subplot(12,2,[2 4]);
plot(t2_plot/1000,L2*10^-3,'LineWidth', 1.5, 'Color', 'k'); 
ylabel({'Ligand' , '[mM]'});
xlim([t_start_plot t_end_plot]);
set(gca,'FontSize',20);
set(gca,'XTickLabel',[]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';
set(gca,'YTick',[0 0.8]);

subplot(12,2,[6 8]);
L_dev2 = [0 ; diff(L2*10^-3) ./ diff(t2_plot/1000) .* 1000];
L_dev2(abs(L2 - 0.1150) < 1) = 0;
plot(t2_plot/1000,L_dev2,'LineWidth', 1.5, 'Color', 'k'); 
ylabel({'dL/dt' , '[\muM/Sec]'});
ylim([-0.2*max(L_dev2(2:end)),1.2*max(L_dev2(2:end))]);
xlim([t_start_plot t_end_plot]);
set(gca,'FontSize',20);
set(gca,'XTickLabel',[]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';
set(gca,'YTick',[0 3]);

subplot(12,2,[10 12 14]);
plot(time_exp2,flur_exp2,'LineWidth', 1.5, 'Color', 'b')
xlim([t_start_plot t_end_plot]);
ylim([-0.1*max(flur_exp2),1.1*max(flur_exp2)]);
ylabel('\DeltaF/F_0');
set(gca,'FontSize',20);
set(gca,'XTickLabel',[]);
set(gca,'YTick',[0 1.5]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';

subplot(12,2,[16 18 20]);
plot(t2_plot/1000,Ca2*10^6,'LineWidth', 1.5, 'Color', 'b'); 
ylabel({'Calcium', 'conc. [\muM]'});
ylim([-0.1*max(Ca2*10^6),1.1*max(Ca2*10^6)]);
xlim([t_start_plot t_end_plot]);
set(gca,'FontSize',20);
set(gca,'XTickLabel',[]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';
set(gca,'YTick',[0 50]);

subplot(12,2,[22 24]); 
yyaxis right; plot(t2_plot/1000,m2,'LineWidth', 1.5); 
ylabel('Inhibition');
ylim([-0.03*max(m2),1.03*max(m2)]);
yyaxis left; plot(t2_plot/1000,a2,'LineWidth', 1.5);
ylabel({'Receptor','activation'});
ylim([-0.05,1.05]);
xlabel('Time [Sec]');
xlim([t_start_plot t_end_plot]);
set(gca,'FontSize',20);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';       
yyaxis left; set(gca,'YTick',[0 1]);
yyaxis right; set(gca,'YTick',[0 6]);  

annotation('line',[0.775372124492558 0.77567774612092],[0.92094861660079 0.253952569169957],...
    'Color',[0.501960784313725 0.501960784313725 0.501960784313725],...
    'LineWidth',2,...
    'LineStyle','--');
annotation('arrow',[0.598105548037889 0.598105548037889],[0.866588932806323 0.810276679841897]);
annotation('textbox',[0.569082575447653 0.850918377701858 0.162080215250021 0.0649453120748688],'String',{'simulated gradient','starts'},...
    'LineStyle','none',...
    'HorizontalAlignment','center',...
    'FontSize',14,...
    'FitBoxToText','off');