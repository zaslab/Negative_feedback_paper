%% generate simulation data (long running time, data in the 'Figure_6_simulation_data' mat file)

% % %WT first step long
% [t1 , Ca1, L1, m1, V1] = GPCR_negative_feedback_simulation('ez',true,'model_type',2,'time_track',true,...
%            'gradType',7,'t_end',500000,'ts',30000,'tf',465000,'amplitude',DAMToUM(10^-4),...
%             'step_duration', 300000, 'break_duration', 120000);          
% 
% % %WT first step short
% [t2 , Ca2, L2, m2, V2] = GPCR_negative_feedback_simulation('ez',true,'model_type',2,'time_track',true,...
%            'gradType',7,'t_end',500000,'ts',30000,'tf',465000,'amplitude',DAMToUM(10^-4),...
%             'step_duration', 60000, 'break_duration', 360000); 
% 
% %tax6 first step long
% [t3 , Ca3, L3, m3, V3] = GPCR_negative_feedback_simulation('ez',true,'model_type',2,'time_track',true,...
%            'gradType',7,'t_end',500000,'ts',30000,'tf',465000,'amplitude',DAMToUM(10^-4),...
%             'step_duration', 300000, 'break_duration', 120000,'calcium_dependent_inhibition_coeff',0);  
% % %WT tanh
% [t4 , Ca4, L4, m4, V4] = GPCR_negative_feedback_simulation('ez',true,'model_type',2,'time_track',true,...
%            'gradType',3,'t_end',1020000,'ts',100000,'tf',1020000,'amplitude',DAMToUM(10^-4)/2*0.7);          
%        
% % tax6 tanh
% [t5 , Ca5, L5, m5, V5] = GPCR_negative_feedback_simulation('ez',true,'model_type',2,'time_track',true,...
%            'gradType',3,'t_end',1020000,'ts',100000,'tf',1020000,'amplitude',DAMToUM(10^-4)/2*0.7,'calcium_dependent_inhibition_coeff',0);         
%% load data
load('Figure_6_simulation_data.mat');
load('Figure_6_Experimental_data.mat');

time_wt_tanh = wt_tanh(1).timeInSeconds - 605.46; 
flur_wt_tanh = wt_tanh(1).flurCorrected;
time_t6_tanh = tax6_tanh(1).timeInSeconds - 590; 
flur_t6_tanh = tax6_tanh(1).flurCorrected;

time_wt_5min = wt5Min.timeInSeconds{1,1} - 30; 
flur_wt_5min = wt5Min.flurCorrected{1,1};
time_t6_5min = tax6_5Min.timeInSeconds{1,1} - 33; 
flur_t6_5min = tax6_5Min.flurCorrected{1,1};

time_wt_1min = wt1Min.timeInSeconds{1,1} - 30; 
flur_wt_1min = wt1Min.flurCorrected{1,1};
%% panel a,b,c
t1_sync = t1 - 30000;
t2_sync = t2 - 30000;
t3_sync = t3 - 30000;
t4_sync = t4 - (1020000 + 100000)/2;
t5_sync = t5 - (1020000 + 100000)/2;

tanh_time_end = 350;

figure(); 

subplot(9,3,[1]);
plot(t4_sync/1000,L4*10^-3,'LineWidth', 1.5, 'Color', 'k'); 
ylabel({'Ligand' , '[mM]'});
ylim([-0.2*max(L4*10^-3),1.2*max(L4*10^-3)]);
xlim([min(t4_sync/1000) tanh_time_end])
set(gca,'FontSize',18);
set(gca,'YTick',[0 0.8]);
set(gca,'XTickLabel',[]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';

subplot(9,3,[4 7 10]);
plot(time_t6_tanh,flur_t6_tanh,'LineWidth', 1.5, 'Color','r'); 
hold on;
plot(time_wt_tanh,flur_wt_tanh,'LineWidth', 1.5, 'Color', 'b'); 
ylabel('\DeltaF/F_0');
ylim([-0.05*max(flur_t6_5min),1.05*max(flur_t6_5min)]);
xlim([min(t4_sync/1000) tanh_time_end])
legend('{\it tax-6}','wt')
set(gca,'FontSize',18);
set(gca,'XTickLabel',[]);
set(gca,'YTick',[0 3 6]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';


subplot(9,3,[13 16 19]);
plot(t5_sync/1000,Ca5*10^6,'LineWidth', 1.5, 'Color','r'); 
hold on;
plot(t4_sync/1000,Ca4*10^6,'LineWidth', 1.5, 'Color', 'b'); 
ylabel({'Calcium Conc.','[\muM]'});
ylim([-0.05*max(Ca5*10^6),1.05*max(Ca5*10^6)]);
xlim([min(t4_sync/1000) tanh_time_end])
set(gca,'FontSize',18);
set(gca,'XTickLabel',[]);
set(gca,'YTick',[0 400 800]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';

subplot(9,3,[22 25]);
plot(t5_sync/1000,V5,'LineWidth', 1.5, 'Color','r');
hold on;
plot(t4_sync/1000,V4,'LineWidth', 1.5, 'Color','b'); 
ylabel({'Membrane' ,'Potential [mV]'});
xlim([min(t4_sync/1000) tanh_time_end])
set(gca,'FontSize',18);
set(gca,'YTick',[-70 -40 -10]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';
xlabel('Time [Sec]');

subplot(9,3,[2]);
plot(t1_sync/1000,L1*10^-3,'LineWidth', 1.5, 'Color', 'k'); 
ylim([-0.2*max(L1*10^-3),1.2*max(L1*10^-3)]);
xlim([min(t1_sync/1000) max(t1_sync/1000)])
set(gca,'FontSize',18);
set(gca,'XTickLabel',[]);
set(gca,'YTick',[0 1]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';

subplot(9,3,[5 8 11]);
plot(time_t6_5min,flur_t6_5min,'LineWidth', 1.5, 'Color', 'r'); 
hold on;
plot(time_wt_5min,flur_wt_5min,'LineWidth', 1.5, 'Color', 'b');
%ylabel({'Calcium Conc.','[\muM]'});
ylim([-0.05*max(flur_t6_5min),1.05*max(flur_t6_5min)]);
xlim([min(t1_sync/1000) max(t1_sync/1000)])
legend('{\it tax-6}','wt')
set(gca,'FontSize',18);
set(gca,'XTickLabel',[]);
set(gca,'YTick',[0 3 6]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';

subplot(9,3,[14 17 20]);
plot(t3_sync/1000,Ca3*10^6,'LineWidth', 1.5, 'Color', 'r'); 
hold on;
plot(t1_sync/1000,Ca1*10^6,'LineWidth', 1.5, 'Color', 'b');
ylim([-0.05*max(Ca3*10^6),1.05*max(Ca3*10^6)]);
xlim([min(t1_sync/1000) max(t1_sync/1000)])
set(gca,'FontSize',18);
set(gca,'XTickLabel',[]);
set(gca,'YTick',[0 400 800]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';

subplot(9,3,[23 26]);
plot(t3_sync/1000,V3,'LineWidth', 1.5, 'Color','r');
hold on;
plot(t1_sync/1000,V1,'LineWidth', 1.5, 'Color','b'); 
xlim([min(t3_sync/1000) max(t3_sync/1000)])
%legend('tax6','wt')
set(gca,'FontSize',18);
set(gca,'YTick',[-70 -40 -10]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';
xlabel('Time [Sec]');

subplot(9,3,[3]);
plot(t2_sync/1000,L2*10^-3,'LineWidth', 1.5,'LineStyle','--', 'Color', 'k'); hold on;
plot(t1_sync/1000,L1*10^-3,'LineWidth', 1.5, 'Color', 'k'); 
ylim([-0.2*max(L2*10^-3),1.2*max(L2*10^-3)]);
xlim([min(t2_sync/1000) max(t2_sync/1000)])
set(gca,'FontSize',18);
set(gca,'YTick',[0 1]);
set(gca,'XTickLabel',[]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';


subplot(9,3,[6 9 12]);
plot(time_wt_1min,flur_wt_1min,'LineWidth', 1.5, 'Color', 'm'); hold on;
plot(time_wt_5min,flur_wt_5min,'LineWidth', 1.5, 'Color', 'b');
ylim([-0.05*max(flur_wt_1min),1.05*max(flur_wt_1min)]);
xlim([min(t2_sync/1000) max(t2_sync/1000)])
legend('wt short-step','wt long-step');
set(gca,'FontSize',18);
set(gca,'XTickLabel',[]);
set(gca,'YTick',[0 1.5 3]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';

subplot(9,3,[15 18 21]);
plot(t2_sync/1000,Ca2*10^6,'LineWidth', 1.5, 'Color', 'm'); hold on;
plot(t1_sync/1000,Ca1*10^6,'LineWidth', 1.5, 'Color', 'b');
ylim([-0.05*max(Ca3*10^6),1.05*max(Ca3*10^6)]);
xlim([min(t2_sync/1000) max(t2_sync/1000)])
set(gca,'FontSize',18);
set(gca,'XTickLabel',[]);
set(gca,'YTick',[0 400 800]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';

subplot(9,3,[24 27]);
plot(t2_sync/1000,V2,'LineWidth', 1.5,'Color', 'm'); hold on;
plot(t1_sync/1000,V1,'LineWidth', 1.5, 'Color','b'); 
xlim([min(t2_sync/1000) max(t2_sync/1000)])
set(gca,'FontSize',18);
set(gca,'YTick',[-70 -40 -10]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'of';
xlabel('Time [Sec]');

annotation('line',[0.775372124492558 0.77567774612092],[0.92094861660079 0.253952569169957],...
    'Color',[0.501960784313725 0.501960784313725 0.501960784313725],...
    'LineWidth',2,...
    'LineStyle','--');

% Create line
annotation('line',[0.411420204978038 0.623718887262079],...
    [0.667 0.667],'Color',[0 0 1],'LineStyle','--');

% Create line
annotation('line',[0.410688140556369 0.624450951683748],...
    [0.820 0.820],'Color',[1 0 0],'LineStyle','--');

% Create line
annotation('line',[0.410688140556369 0.623718887262079],...
    [0.5392 0.5392],'Color',[1 0 0],'LineStyle','--');

% Create line
annotation('line',[0.410688140556369 0.624450951683748],...
    [0.501 0.501],'Color',[0 0 1],'LineStyle','--');

% Create line
annotation('line',[0.691800878477308 0.904099560761347],...
    [0.50 0.50],'Color',[0 0 1],'LineStyle','--');

% Create line
annotation('line',[0.692532 0.9048316],...
    [0.81950 0.8195084],'Color',[1 0 1],'LineStyle','--');

% Create line
annotation('line',[0.691068814 0.904099],...
    [0.7806298 0.78062980],'Color',[0 0 1],'LineStyle','--');
