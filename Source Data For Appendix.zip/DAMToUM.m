function [ uM ] = DAMToUM( volumeFraction )
%DAMTOUM Summary of this function goes here
%   Detailed explanation goes here
DA_MW = 86.09; %gram/mol;
DA_Density = 0.990*1000; %gram/liter;
pureDA_UM = DA_Density/DA_MW*10^6;

uM = pureDA_UM*volumeFraction;
end

